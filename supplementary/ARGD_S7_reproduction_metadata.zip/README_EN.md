> Public release copy, prepared on 8 November 2026. Machine-local workspace roots in this copy use `PUBLIC_PATH_REDACTED/`. Original source identities and numerical observations are retained. Historical byte-preservation statements below describe the retained submission source. The public-copy file hashes are listed in this archive's manifest and in the repository publication records. Consult `PUBLICATION_PROVENANCE.md` in the repository for the public-copy scope.

# ARGD S7, protocol reproduction metadata

This metadata-only companion makes the recorded protocols inspectable. It is
not an independent experiment execution package and does not claim a new clean
room reproduction. No research executor, Java test source, candidate patch,
vulnerability payload or model service is supplied or executed here.

## Contents

- identities_sha256.csv preserves the audited commit, tree, XML, method-excerpt
  and source identities with original source pointers and source SHA256.
- recorded_command_argv.json preserves 32 native command records and 22 formal
  historical candidate-stage command records. Historical argv and cwd strings
  remain intact as metadata. They are not executed or resolved automatically.
- native_maven_command_definitions.csv includes the complete native cmd_options.
  The frozen CLI appends them to compile and PoV. Its all stage uses the exact
  test_all_cmd, mvn test -pl xwork-core, without guessed additional parameters.
- junit_matrix_methods.csv gives the full Java and JUnit identities of the four
  frozen methods, the complete class-source SHA256, exact byte ranges and
  per-method SHA256. These are hashes and signatures, not executable Java code.
- four_and_six_input_fixtures.csv lists the four common legitimate names and
  the two added names, their assertion and method/source identities.
- environment_and_resource_boundaries.json records the observed toolchains,
  environment, resource limits and their scope.
- network_boundaries.csv distinguishes historical test-container isolation
  from the absence of equivalent native isolation evidence.
- missing_evidence_and_claim_limits.json lists unresolved items explicitly.
- original_source_hashes.csv identifies the separately retained original files.
- PACKAGE_MANIFEST_SHA256.csv verifies every supplied member except itself.

## How to inspect

Open the JSON and CSV files with ordinary tools. Map project_evidence to a
separately retained ARGD source root and workspace_evidence to its parent only
when intentionally checking original sources. Absolute paths inside argv are
historical runtime locators, not portable execution defaults. No command runner
or automatic dependency download is provided. S3 and S6 remain separate
companions. Access to external original artifacts is not created by S7.

## Experimental boundaries

The native/V3 environment was Zulu Java 7u352 and Maven 3.3.9. Benchmark child
processes ran as UID/GID1000 with four-CPU affinity, an inherited per-process
8 GiB virtual-memory limit and a 900-second stage timeout. The 30 GiB directory
size threshold was a before-stage check, not a hard filesystem quota.

Recovery3 used Temurin Java 8u392 and Maven 3.8.8 in fixed Docker containers.
Formal historical tests used --network none and Maven -o. Acquisition and
dependency prewarm were separate phases. Native/V3 did not show equivalent
forced network isolation. V3's network_used=false was a statically written
result field, not an instrumented traffic measurement.

Two retained 4724-entry native input manifests differ only at the production
XML. The separately added matrix source is identical across the controls and
is hashed independently. The audit rechecked these manifests and twelve key
retained source copies, not all active worktree bytes. The matrix observes an
inert-name exclusion subdecision, not full OGNL or HTTP exploit execution.

Seven native candidates passed compilation but failed native validation. Their
native candidate matrix was not run. Earlier four-input checker passes and
historical matrix outcomes are separate protocol observations. The earlier
and native environments also differ, so this is not a matched input-only
causal experiment or a general method-performance estimate.

This is an author-review metadata companion. Packaging created no new
experiment, network request, model call, publication or submission.
