# Pillow CVE-2026-42310 V1R4 结果报告

日期：2026-10-31（北京时间）  
类型：公开、非盲、单一候选的行为探索  
范围：三个代码版本 × 三个场景，共九个版本-场景观察；不调用模型或付费 API。

## 结论

在修正且独立核验过的合法 PDF 输入上，公开 AI 候选与漏洞版本都接受同偏移结构的第二份 PDF；维护者修复版本却将其拒绝为 trailer loop。三版本都拒绝官方 trailer-loop PoV，三版本首次解析合法四版增量链均通过。该结果支持一个受限的兼容性回归信号：维护者的循环检测状态泄漏到后续解析器实例，而该候选使用实例级状态避免了该问题。

这是一项来自 CVE-Bench 公开非盲补丁的跨项目行为观察，不是新发现的配置遗漏、不是确认的产品缺陷，也不构成方法普遍优势或发生率证据。

## 冻结对象与验证前提

- 项目：`python-pillow/Pillow`；漏洞提交 `3cb854e8b2bab43f40e342e665f9340d861aa628`；维护者修复提交 `3bf614e4b8615d0ce1d5039efaf6db447fe7c468`。
- 候选：`CVE-2026-42310__openai_gpt-5.4-mini__locate`，来自 CVE-Bench AI Repair 派生补丁；候选差异 SHA-256 `65ebffe8b0b1e057568e59cd46a8556328918de52c75bb494a627944d1bc13f1`。
- 正式输入清单中的文件哈希均与落盘文件匹配。两个合法增量 PDF 都为 887 字节，SHA-256 分别为 `8f9db5746b97d393b15f2d56741ed719eb4f4bd59bf9ffcf0bee1884eeab775a` 和 `850c0fb3d2a7f7b256ec2fe30e8e01c91be7854920b4af49a8758665828b5340`。两者字节不同，最终 Catalog 的 `/Mark` 分别为 4 与 5；文件长度、`/Prev` 值和 `startxref` 值相同。两份文件均由 `pdfinfo` 独立确认一页。
- T0：三版本都接受合法单版 PDF；WSL 原生 Docker，固定镜像 `python:3.12-slim@sha256:aa943ce411423c7582288f18707ff66eddcbaeb510502d747a72aeb34f30d159`，网络关闭、容器 UID 65534、只读根文件系统。

## 结果

| 场景 | 漏洞版本 | AI 候选 | 维护者修复 |
|---|---|---|---|
| 官方 trailer-loop PoV | `RecursionError` | `PdfFormatError` | `PdfFormatError` |
| 合法四版增量链首次解析 | 接受 | 接受 | 接受 |
| 同偏移、不同内容的第二份 PDF | 接受 | 接受 | `PdfFormatError: trailer loop found` |

矩阵原始 JSON：`execution/argd_pillow_cve2026_42310_v1r4_formal_20261031_01/outputs/matrix.json`；SHA-256 `ccbd99fbbbfc9c64c65d0f9726012ddecab6a3f1c2894d14cdd55e0eb55d832d`。执行状态 `SUCCEEDED`，exit 0。T0 状态 `SUCCEEDED`，exit 0，原始输出在对应 `execution/argd_pillow_cve2026_42310_v1r4_t0_20261031_01/outputs/t0.json`。

## 机制解释与边界

冻结维护者源码把 `processed_offsets` 定义为可变默认列表 `[]`，因此不同 `PdfParser` 实例共享偏移记录；第一份 PDF 解析过的偏移会让第二份 PDF 的相同偏移触发误报。候选把集合存放在各 parser 实例上。这个源码差异与受控矩阵观察一致。

测试直接实例化 `PdfParser`，使用小型但被 `pdfinfo` 接受的合法 PDF。尚未验证 Pillow 高层 API 的真实业务调用路径、不同版本的公开契约或生产影响。因此应称“候选与维护者修复在所测合法 PDF 邻近场景上出现行为差异；观察与维护者补丁的共享状态相符”，不能称“确认的 Pillow 产品缺陷”或“发现第二个漏洞”。结果也不能并入 VUL4J-32 的配置遗漏计数。

## 门禁读回

V1R4 执行包的 `formal_request.json` 记载精确 scope 门禁已通过。当前 project-level T0 指针后来已被 Libtiff scope 更新；为重新核验，审计时暂时将指针切回 V1R4 scope 内的 T0 清单，`get_experiment_gate_status(phase="formal")` 返回 `WARN / ready_for_formal_run=true / blockers=[]`，唯一警告为 `GIT_COMMIT_UNAVAILABLE`，随后已将根指针恢复为原 Libtiff 内容并校验 SHA-256。历史门禁 readback 未随执行包保存，因此本报告区分原执行请求声明与本次可复查的重新核验。

## 可复核入口

- 协议：`protocol/PILLOW_CVE2026_42310_MATRIX_PROTOCOL_V1_CN.md`
- 修订说明：`V1R4_AMENDMENT_CN.md`
- 文件身份与哈希：`inputs/FROZEN_INPUTS_MANIFEST.json`
- PDF 页数核对：`evidence/PDFINFO_PRECHECK_V1R4.txt`
- T0 回执：`evidence/T0_RECEIPT_V1.json`
- 矩阵输出：`execution/argd_pillow_cve2026_42310_v1r4_formal_20261031_01/outputs/matrix.json`
- V1R3 输入问题复核：`PUBLIC_PATH_REDACTED/ARGD/02_experiments/runs/ARGD_PILLOW_CVE2026_42310_VALIDATION_EXPLORATORY_20261031_V1R3/evidence/POSTRUN_INDEPENDENT_AUDIT_CN.md`