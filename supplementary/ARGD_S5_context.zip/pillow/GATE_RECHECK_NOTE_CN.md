# V1R4 正式门禁重新核验记录

核验时间：2026-10-31 11:06 Asia/Shanghai。原 project-level `T0_EVIDENCE.json` 当时指向已完成的 Libtiff scope；精确 V1R4 查询因此显示 `T0_EVIDENCE_MISSING`。为验证 V1R4 当前材料的可读性，先将根 T0 指针暂时切换为本 scope 的 `T0_EVIDENCE.json`，重新查询同一精确 scope；工具返回 `status=WARN`、`ready_for_formal_run=true`、`blockers=[]`，唯一 warning 是 `GIT_COMMIT_UNAVAILABLE`。随后从 `T0_EVIDENCE_ROOT_CURRENT_BEFORE_RECHECK_20261031.json` 恢复原根文件，SHA-256 为 `0503756d485acdc867140189c06f2f37928dca97beb961a661415909080a8dd7`。

这项当前重新核验确认冻结 scope、T0 回执及 run-local traceability ledger 可被正式门禁识别。它不是原执行时的历史 readback；原执行包中的 `formal_request.json` 记录已通过，但未保存独立的 gate readback。