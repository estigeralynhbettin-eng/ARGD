# libtiff CVE-2016-5321 公开 AI 补丁执行结果

日期：2026-10-31。实验为公开、非盲单候选复现。

## 冻结对象和条件

- 项目/漏洞：libtiff `tiffcrop`，CVE-2016-5321。
- 漏洞版提交：`0ba5d8814a17a64bdb8d9035f4c533f3f3f4b496`。
- 参考修复来源：L-AVRBench 固定提交 `9099a3aea88f6e79082f12fe7e05949256f04bf5`，样本 LB9。
- AI 补丁：Zero-Shot Vulnerability Repair 归档 Zenodo 10.5281/zenodo.7199939，HTML 中 `EF01: CVE-2016-5321 in libtiff / code-davinci-002` 的原始差异；补丁 SHA-256 `2e52d0b6c3b4e81b9c016594462984a58c8fa46d896af00089a3a92b04fe035f`。公开材料没有可确认的 CSV 行号映射，本报告只指明该精确差异。
- 容器：`rimwoohan/lavrbench@sha256:9e99a6b655554c417e5337f4563a490a36759fcae3d2cb18e518e7e452ef9723`；WSL 原生 Docker，容器网络关闭；漏洞版、候选版、修复版分别隔离运行；未调用模型或 API。
- T0 先在漏洞版和修复版核对同一官方 ASAN PoV 与功能测试。T0 结果：两版均编译通过、功能测试各 74/74；漏洞版触发 AddressSanitizer，修复版未触发。正式门禁读回 `ready_for_formal_run=true`，无阻断，仅有项目 Git commit 不可用警告。

## 候选版观察

冻结差异干净应用（退出码 0）、编译通过（退出码 0）、官方安全测试通过（退出码 0）、功能测试通过（退出码 0，74/74）。原始安全日志显示畸形输入在读取样本索引越界时被拒绝并正常结束，未出现 ASAN 报告。与漏洞版和开发者修复版控制相比较，这个精确公开补丁修复了该官方 PoV 覆盖的已知行为，并保留了所跑的功能测试。

## 结论边界

这是一个独立 CVE 家族上的公开 AI 补丁有效案例，可作为方法实证中的正向对照材料。它没有显示补丁遗漏，也不能增加“检测到遗漏”的案例数。后续为有效分离场景建立的邻近输入 T0 在 V1R4 工程准备中退出 127，未执行候选或邻近测试；不得把它写成通过或失败结果。

## 原始证据

- T0 原始控制结果：`evidence/T0_V1R2/runner_run/outputs/T0_RESULT.json`。
- 候选汇总和状态：`evidence/CANDIDATE_V1R2/runner_run/outputs/CANDIDATE_RESULT.json`、`evidence/CANDIDATE_V1R2/runner_run/status.json`。
- 完整日志：同一 runner 输出目录中的 `sec_test.log`、`func_test.log`、`compile.log` 及各退出码文件。
- 冻结协议：`protocol/PROTOCOL_CN.md`；输入身份与哈希见 `inputs/FROZEN_INPUTS_MANIFEST.json`。

该结果由状态文件、T0 控制 JSON、候选 JSON、原始日志和退出码交叉核验；尚未完成第二名独立审阅者复核。它不登记为配置遗漏或方法优势结果。
