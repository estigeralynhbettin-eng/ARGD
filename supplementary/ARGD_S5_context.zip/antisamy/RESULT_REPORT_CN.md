# V1R7 六策略扩展结果报告

日期：2026-10-31（Asia/Shanghai）  
运行范围：`ARGD_ANTISAMY_CVE_2017_14735_SIX_POLICY_EXTENSION_20261031_V1R7`  
状态：测量 runner 成功；240 条记录经独立行级复核脚本核对通过。

## 研究问题与实验设计

本扩展检查 AntiSamy CVE-2017-14735 的同一上游父提交和修复提交，观察上游修改过的六份策略 XML 在两种解析器和固定 issue10 输入下的行为。Java 与 XML 组成四个对照臂，每个臂对六份策略、DOM/SAX 两种解析器和五个固定输入运行一次，共 4 × 6 × 2 × 5 = 240 项。五个输入包括一个恶意输入和四个合法 href 输入。

| 臂 | Java | XML |
|---|---|---|
| A1 | 漏洞版 | 旧版 |
| A2 | 修复版 | 旧版 |
| A3 | 漏洞版 | 修复版 |
| A4 | 修复版 | 修复版 |

实验使用预先固定的 AntiSamy 源码提交、JDK 8u504、Maven 3.6.3、独立 Maven 仓库及本地测试输入。源码对象复用已核验的 V1R1 仓库；没有新增取源、外部模型调用、付费 API 或外部目标请求。V1R7 的 T0 检查通过后才启动测量。

## 结果

240/240 项观察均有唯一键，四臂各 60 项；四次 Maven 测试调用均退出码为 0，JUnit 各报告 1 项测试、0 failures、0 errors、0 skipped。未观察到扫描异常，所有输入均返回了扫描结果并生成了对应观察记录。V1R7 与 V1R6 重叠的 80 项逐字段比较一致，包括输入、清理后 HTML、异常字段、扫描完成标记、预言名称及观察值。

对恶意 issue10 输入，五份策略的 DOM 和 SAX 结果一致：

| 策略 | A1 漏洞 Java+旧 XML | A2 修复 Java+旧 XML | A3 漏洞 Java+修复 XML | A4 修复 Java+修复 XML | 可归因结果 |
|---|---|---|---|---|---|
| antisamy.xml | 攻击保留 | 攻击保留 | 攻击拦截 | 攻击拦截 | 支持 XML 因子模式 |
| antisamy-ebay.xml | 攻击保留 | 攻击保留 | 攻击拦截 | 攻击拦截 | 支持 XML 因子模式 |
| antisamy-anythinggoes.xml | 攻击保留 | 攻击保留 | 攻击拦截 | 攻击拦截 | 支持 XML 因子模式 |
| antisamy-myspace.xml | 攻击保留 | 攻击保留 | 攻击拦截 | 攻击拦截 | 支持 XML 因子模式 |
| antisamy-slashdot.xml | 攻击保留 | 攻击保留 | 攻击拦截 | 攻击拦截 | 支持 XML 因子模式 |
| antisamy-tinymce.xml | 四臂均拦截 | 四臂均拦截 | 四臂均拦截 | 四臂均拦截 | 漏洞版基线已拦截，不能归因 |

上述模式在五份策略的两个解析器中均复现，即 10/12 个“策略 × 解析器”组合满足预先设定的两端控制条件，并呈现“只改 Java 仍保留、只改 XML 已拦截”。`antisamy-tinymce.xml` 在旧 Java、旧 XML 下已拦截该输入，未满足漏洞版控制条件，因此不用于判断 Java/XML 因素的必要性或充分性。

四个合法输入共 192 项观察中，188 项保留 href，4 项移除了 href；4 项全部是 `antisamy-tinymce.xml` 的 `onsite_4` 输入，发生在 A1、A2 的 DOM/SAX 执行。协议未冻结该策略对此输入的独立行为契约，因此这里只作描述性记录，不判为过度修复或功能缺陷。

## 结论边界

本实验在一个固定 CVE 家族、一个上游父/修复提交、一个恶意输入、四个合法输入和六份明确载入的发行策略范围内，显示 XML 策略更新对五份策略中的 issue10 拦截行为具有决定性作用：在旧 XML 下更新 Java 没有改变该输入的结果，而单独换成修复 XML 后攻击被拦截。该结果为“配置变更会参与安全修复行为”提供了扩展的受控证据。

V1R7 没有新增独立漏洞案例，也没有直接检查另一个数据集中的候选补丁是否漏带 XML；它不能被计为第二个 XML 遗漏案例或新的基准缺陷。结果不估计 XML 漏检发生率，不外推至定制策略、其他输入、其他项目或其他漏洞。Tinymce 结果不能用于修复因素归因。合法输入的四次 href 移除缺少独立契约，不作功能错误结论。

结果 JSON 中 `assertion_reached` 是测试 harness 对“扫描调用返回并计算了观察值”的标记，并非独立判定安全性质正确性的断言。Runner 的 `scientific_validation=false`；以下复核是与测量驱动分离的行级复算，不等于第二位研究者的盲审。

## 复核与证据

- 冻结协议：[ANTISAMY_SIX_POLICY_EXTENSION_V1_CN.md](../protocol/ANTISAMY_SIX_POLICY_EXTENSION_V1_CN.md)
- 240 项原始结果：[MEASURE_RESULT_V1R7.json](MEASURE_RESULT_V1R7.json)
- 独立行级对账：[V1R7_INDEPENDENT_AUDIT.json](V1R7_INDEPENDENT_AUDIT.json)
- 可读策略×解析器汇总：[V1R7_POLICY_PARSER_SUMMARY.csv](V1R7_POLICY_PARSER_SUMMARY.csv)
- 原始四臂 CSV：[raw_csv/](raw_csv/)
- 原始 JUnit 报告：[surefire/](surefire/)
- 四臂执行日志：[scientific_logs/](scientific_logs/)
- 运行器回执与日志：[runner/](runner/)
- 复核脚本：[verify_v1r7_results.ps1](../tools/verify_v1r7_results.ps1)
- 范围数字澄清：[SCOPE_AMENDMENT_02_CN.md](../SCOPE_AMENDMENT_02_CN.md)

复现行级复核：从项目 PowerShell 运行 `pwsh -NoProfile -File PUBLIC_PATH_REDACTED/ARGD\02_experiments\runs\ARGD_ANTISAMY_CVE_2017_14735_SIX_POLICY_EXTENSION_20261031_V1R7\tools\verify_v1r7_results.ps1`。脚本核对测量 JSON 与原始 CSV、JUnit 计数、四臂完整性、240 个唯一键及与 V1R6 的 80 项重叠结果。
