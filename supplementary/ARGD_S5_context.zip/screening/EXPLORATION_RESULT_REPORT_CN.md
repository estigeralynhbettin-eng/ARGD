# ARGD 十小时追加探索阶段结果

> **后续补记（2026-10-31 06:05，北京时间）：** 本报告初稿后又完成了一项 libtiff 公开 AI 补丁复现：候选通过官方 ASAN PoV 与 74 项功能测试，可作为独立漏洞家族的已知问题修复正向对照；未增加补丁遗漏发现。另一个冻结的邻近场景 T0 在 V1R4 以 exit 127 结束，未执行任何科学测试；按预置停止规则关闭该支线。详见本报告末尾“后续追加结果”。因此初稿中“未启动新的行为实验”仅指 03:21 的阶段截点，不适用于此补记之后。

核查时间：2026-10-31 03:21（北京时间）  
状态：本阶段已完成样本资格复核；未启动新的行为实验。用户授权的十小时是探索上限，本次未耗满。停止原因是当前筛出的其他生产配置线索都没有匹配的、身份可审计的 AI 候选补丁，强行造补丁或删改配置不能回答“真实候选是否漏修”。

## 结论先行

截至本次核查，**VUL4J-32 仍是唯一已确认的真实补丁配置遗漏案例**。没有找到第二个满足“属于既定补丁数据集—候选与参考修复身份匹配—生产配置安全相关—有效测试可复现行为差异”的独立案例。

本轮得到两类有用的正面进展：

1. AntiSamy V1R7 在同一 CVE 的六类策略中完成 240 项受控实验；五类策略呈现稳定的 Java/XML 因素差异。这加深了单一漏洞的机制证据，但不是第二个 CVE，也不是基准候选遗漏。
2. V6 主扫描与 SAP 对照现均有 runner 终态，生产配置路径线索已与本地补丁索引交叉。最终清点仍显示没有可执行的第二个 AI 候选案例。SAP 完成状态不等于其所有记录均已裁定。

## 本轮范围与冻结条件

- 不改变 V6/SAP 的扫描总体、分类规则、路径准入标准、5% 阈值和原始结果；不重启或改写旧 runner 证据。
- 数据集与候选交叉只用于发现待核线索；不把路径变化直接说成补丁遗漏。
- 未调用外部模型、付费 API；没有用人工删改 XML/配置制造“真实候选”。
- 每个正式行为实验仍要求固定漏洞版、候选版、参考修复版、测试预言、依赖/运行环境，建立新 scope，通过 T0 与正式门禁。

## V6 / SAP 终态核对

只读读取两个 runner 的 `status.json` 与 `BATCH_RESULT.json`：

| 范围 | 计划条目 | PASS_CLASSIFIED | PENDING_MANUAL | UNRESOLVED | 其他状态 | Runner 状态 |
|---|---:|---:|---:|---:|---:|---|
| V6 主体 | 972 | 870 | 55 | 47 | 0 | `ATTEMPTED_PLAN_COMPLETED` |
| SAP 对照 | 920 | 800 | 53 | 40 | 25 `NOT_ATTEMPTED_BY_APPROVED_POLICY`、2 `INVALID_COMMIT_ID_FORMAT` | `ATTEMPTED_PLAN_COMPLETED` |

原始位置：

- 主体 runner：`PUBLIC_PATH_REDACTED/argd_projectkb_simple_v6_20261030/batch_runner/argd_v6_primary_20261030_01/outputs/BATCH_RESULT.json`，SHA-256 `e1341ea7731022266fe444d331a7abc763e7ebbb00a46d05c80fef64ec14f5d0`。
- SAP runner：`PUBLIC_PATH_REDACTED/argd_projectkb_simple_v6_20261030/batch_runner/argd_v6_sap_20261030_01/outputs/BATCH_RESULT.json`，SHA-256 `408bc2bf51eed99da99d0fd79e5e712d397e7ac60ee1628316bf344b96f9242c`。
- 两者均报告 `ATTEMPTED_PLAN_COMPLETED`；这里的 PASS 是扫描器记录分类状态，不是安全补丁正确率或 972/920 个案例均已人工裁定。

## 生产配置线索和候选补丁交叉

本次重读 V6/SAP 完成输出及 SAP 前冻结的 XML 快照。扫描输出中有 234 条生产配置路径记录，覆盖 67 个漏洞标识和 156 个唯一“仓库—提交—路径”组合。按 CVE 与仓库与本地 47,316 行补丁单元索引做精确匹配，得到 10 条 CVEFIXES 维护者提交记录，涉及 9 个补丁单元；这些是修复提交，不是 AI 候选。再按“仓库＋完整提交/父提交哈希”核对，命中仍仅落在 CVEFIXES 与已知 VUL4J-32，没有出现新的 AI 候选单元。

已审本地候选来源交叉结果：

- Vul4J+ V2.0：191 项索引中未发现除 VUL4J-32 外的生产配置候选；其余 AntiSamy 项目不匹配本案外的新候选。
- 本地公开 Vul4J LLM 复现库：255 条 attempt、33 个 CVE；与生产配置候选交集仅有 CVE-2015-1831 / VUL4J-32。该库中的候选标签为 `INEFFECTIVE`；须与 ARGD 实际运行结果分别报告。
- CVE-Bench AI Repair：130 个补丁、9 个 CVE，与候选配置漏洞集的精确交集为 0。
- APR4Vul RQ1/RQ2、SRepair/ThinkRepair、InjectionVul4J：未找到身份匹配的新配置候选。InjectionVul4J 对 AntiSamy 有既有讨论，但不是独立新 CVE；其 UAA 与 jBPM 工件路径也未与本次候选修复身份匹配。
- CVEFIXES 命中只能证明存在维护者修复提交，不能证明 AI 补丁数据集中有相同候选。

详细交叉表与复现脚本：

- `05_reviews/ARGD_10H_EXPLORATION_20261031_V1/V6_PRODUCTION_CONFIG_PATHS.csv`
- `05_reviews/ARGD_10H_EXPLORATION_20261031_V1/V6_EXACT_CVE_PATCH_INDEX_CROSSMATCH.csv`
- `05_reviews/ARGD_10H_EXPLORATION_20261031_V1/V6_PATCH_CROSSMATCH_SUMMARY.json`
- `05_reviews/ARGD_10H_EXPLORATION_20261031_V1/audit_v6_patch_crossmatch.py`

## 最高优先级的独立生产配置线索

这些是“值得进一步研究的安全配置修复”，不是已确认补丁遗漏：

- **Struts CVE-2017-9787**：`struts-plugin.xml` 增加 `xwork.disallowProxyMemberAccess=true`，同一上游提交还修改 OGNL 安全代码和测试。提交确为安全语义相关，但本地候选库中没有身份匹配的 AI 补丁。
- **NiFi CVE-2018-17193**：修复代码与生产 `web.xml` 过滤器注册联动；尚未找到可审计的同案 AI 候选补丁。
- **Cloud Foundry UAA CVE-2017-4992**：生产 `login-ui.xml` 调整为拒绝未显式允许的路由并限制邀请路由；未匹配到同案候选补丁。
- **HBase CVE-2013-2193**：`hbase-default.xml` 将 LDAP POSIX 属性名设为 `uidNumber`/`gidNumber`，但 Java `Configuration.getBoolean` 默认值和 XML 明示值均为 `false`。这是配置路径命中不等于运行行为变化的反例线索；尚无候选补丁，且无需把静态相同默认值夸大成安全遗漏。
- **JGroups CVE-2016-2141**：加密协议、Java 实现、配置文件及测试大幅一并重构，难以单独归因于 XML；没有同案 AI 候选，不宜作为单因素遗漏主案例。
- 另外已检视的 Tomcat、Hadoop、Ranger、Infinispan、OpenCast 等提交，或配置差异是文档/说明，或没有候选身份，或存在多文件混杂；仍应留在筛查台账中，不能计为阳性案例。

完整的候选优先级与原始过程见 `05_reviews/ARGD_10H_EXPLORATION_20261031_V1/EXPLORATION_LOG_CN.md`。

## 已运行实验与失败分支

### AntiSamy V1R7：240 项，已完成

固定 CVE-2017-14735 的 Java/XML 四臂、六份策略、DOM/SAX 两种解析器和五类输入。四臂各 60 项，行级复核通过；与 V1R6 重叠的 80 项逐字段一致。五份策略在两种解析器下都显示：只修 Java 时 issue10 攻击仍存活，修复 XML 后被拦截；Tinymce 的漏洞版本来就拦截，不能用于因素归因。此结果是同一 CVE 的机制扩展，不新增独立漏洞数。

报告：`02_experiments/runs/ARGD_ANTISAMY_CVE_2017_14735_SIX_POLICY_EXTENSION_20261031_V1R7/evidence/V1R7_RESULT_REPORT_CN.md`。

### VUL4J-43 / SRepair-18：V1–V4 封存，科学观察为 0

对象原本是 VUL4J-43 / CVE-2018-20227 的路径遍历候选，候选代码使用字符串前缀判断目录包含关系；计划的相邻目录近邻场景有明确技术理由。但四个版本均未形成候选测试结果：

- V1：Maven 离线缓存缺少依赖，在编译/测试前停止；
- V2：Surefire provider 缺失，没有 JUnit 报告；
- V3：容器工作树权限导致预热停止；
- V4：scope 漏带测试源码，输入校验在预热前停止。

V4 是该候选预先规定的最后一次工程尝试；不创建 V5。四次均不是科学失败，也不是补丁阴性结果。逐次复盘位于 `02_experiments/runs/ARGD_SREPAIR_VUL4J43_18_PATH_PREFIX_20261031_V1/` 至 `..._V4/evidence/`。

### VUL4J-32：当前最强的单案证据

VUL4J 原生人类补丁通过原生 PoV 3/3 和 741 项回归 741/741；矩阵 M32-01 在其打包补丁上失败，而在 Apache 完整修复 XML 控制上通过。Recovery3 又检查 7 个公开候选补丁：它们通过官方 PoV 和回归，却在同一 M32-01 上失败；该遗漏都落在同一 VUL4J-32 漏洞家族，不能计为 7 个独立漏洞。Recovery3 的完整边界与证据见 HANDOFF 和对应运行报告。

## 给 JISA 实证分析的建议

现有材料可以支撑一个**边界明确的单漏洞家族纵深实证研究**：说明怎样从修复来源提取原子要求、用矩阵规划近邻测试、在漏洞版/候选版/参考修复版对照，并通过七个公开候选展示官方 PoV/回归之外的同案缺口。不能把当前材料写成跨漏洞发生率、普遍基准盲区、方法优越性或泛化验证。

要把论文提升为跨漏洞实证研究，下一批应先解决样本问题：新增至少一个身份清楚、与修复提交对应、保留原始测试和可执行基线的独立候选家族；在候选资格审查通过前，不宜再投入长时间构建实验。可优先向公开补丁数据集维护者/作者工件追索现有候选，而不是通过手改 XML 合成“漏修补丁”。

## 未做事项与账本边界

- 本阶段没有新启动正式行为实验；所有新案例线索均停留在静态/来源核验层。
- 未修改 V6/SAP 冻结扫描输入、规则、门槛或旧 runner 证据。
- 未修改 `RESULT_TRACEABILITY.csv`、`CLAIM_EVIDENCE_MATRIX.csv` 或论文。V1R7 和 VUL4J-32 的实验原始文件保持原位。
- V6 的 `PENDING_MANUAL`、`UNRESOLVED`、按策略未尝试和无效提交 ID 均独立保留，不计阴性。

## 收尾复核：AntiSamy V1R6 结果文件与状态文件不一致

2026-10-31 05:05（北京时间）再次核对发现：V1R6 的 `RUN_STATUS.json` 仍标记 `SCIENTIFIC_EXECUTION_RUNNING`、观察数为 0，但其 `evidence/MEASURE_RESULT_V1R6.json` 已记录 `status=PASS`、80/80 条观察、四臂各 20 条；四臂 Maven 返回码均为 0，JUnit 各为 1 test、0 failure/error/skip。V1R7 报告进一步记录与 V1R6 重叠的 80 项逐字段一致。因此可核验地认定 V1R6 的测量结果已落盘并被后续重叠审计覆盖；原 `RUN_STATUS.json` 是未同步的陈旧状态，本次不改写冻结文件。

V1R6 的 80 项是 V1R7 240 项中的重叠核对集，不能与 V1R7 相加并声称 320 项独立观察。V1R4 的运行状态仍为 `SCIENTIFIC_EXECUTION_RUNNING`、科学结果文件未见；V1R5 仍显示 `T0_RUNNING`，未见科学结果。当前 Windows/WSL 进程快照未见 V1R4/V1R5/V1R6、V6/SAP 或 Bugsink 相关实验进程。V1R4/V1R5 保持失败/未完成分支，不归入科学结果；V1R6 的原始结果与 V1R7 重叠审计保持可追溯。

本复核未重跑测试、未启动新实验，未修改冻结的 `RUN_STATUS.json`、根 `RESULT_TRACEABILITY.csv`、扫描规则或论文。它补充修正本报告中对 V1R6 状态的描述，不改变“唯一确认的独立配置遗漏仍为 VUL4J-32”的结论。

## 后续追加结果（2026-10-31 06:05，北京时间）

### Zero-Shot libtiff CVE-2016-5321：公开候选通过已知检查

单候选、公开非盲复现使用固定漏洞提交 `0ba5d8814a17a64bdb8d9035f4c533f3f3f4b496`、L-AVRBench LB9 开发者修复来源、固定容器镜像摘要和 Zenodo 10.5281/zenodo.7199939 的 EF01/code-davinci-002 原始补丁。漏洞版 T0 的官方 PoV 触发 ASAN，开发者修复版不触发；两者功能测试均 74/74。精确 AI 差异应用与编译成功，候选官方安全测试通过且无 ASAN，功能测试 74/74 通过。该结果表明该公开 AI 补丁覆盖了已测的已知问题并保留所测功能；不能称作新遗漏或矩阵新增检出。完整冻结条件和证据见 `02_experiments/runs/ARGD_ZEROSHOT_LIBTIFF_CVE20165321_MATRIX_20261031_V1R2/evidence/CANDIDATE_V1R2/LIBTIFF_CANDIDATE_RESULT_REPORT_CN.md`。

同一 CVE 的邻近输入在独立 V1R4 T0 失败：exit 127、无输出，没有编译或科学测试。脚本静态审查发现残留 V1R3 根路径及挂载相对路径不一致，但日志不足以断言这就是退出的直接原因。故障分类为未分类的设置/协议问题，科学失败不具资格。V1R4 是预定唯一后继，按冻结停止规则不建立 V1R5。报告见该 scope 的 `evidence/T0_FAILURE_REVIEW_CN.md`。

至此，追加探索得到一个独立公开 AI 补丁的正向复现，以及一个未运行成功的邻近测试分支；**仍没有发现 VUL4J-32 之外的配置遗漏案例**。没有可核验的新候选时，停止新增行为测试；现有证据更适合支撑单案纵深分析和跨项目的正负/兼容性对照，不足以支持跨漏洞配置遗漏发生率或方法普遍优势。

## 2026-10-31 后续追查（截至 2026-10-31 10:24:21 +08:00，北京时间）

在 06:33 开始的最多十小时追加探索中，进一步审查了两条 FLAWED 公开候选支线。Gemini CLI 五个固定候选的 V1R2 停在输出目录冲突，科学观察为 0；ActiveMQ 单候选的 V1 发生两次 Maven 设置错误，V2 在依赖准备期间执行会话中断，完整日志未能持久化。各分支均按冻结停止规则封存，均不作为阴性结果或新缺陷。详见 EXPLORATION_LOG_CN.md 及各 scope 的失败复核。

本地资源索引仍显示既有 SRepair、Vul4J、CVE-Bench 来源；没有发现新的、与上游安全配置改动身份匹配且可执行的 AI 候选补丁。故阶段性结论仍是 **VUL4J-32 为唯一确认的独立配置遗漏案例**。AntiSamy 的 240 项属于同一 CVE 的机制结果；libtiff 证明一个公开补丁通过已知安全与功能检查；Bugsink 仅显示一项缺少契约裁定的兼容性差异。后二者可辅助构成 JISA 讨论中的不同观察类型，不能加进配置遗漏计数。

十小时是探索授权上限。本阶段在没有合格新候选时提前停止行为实验，避免反复消耗在已封存工程分支上。现有证据可支撑单一漏洞家族的纵深实证分析；若坚持跨漏洞发生率或普遍方法效果，仍需新的身份独立、可复现候选。

## 2026-10-31 11:06 后续结果：Pillow CVE-2026-42310

V1R4 修正并冻结了两份不同内容、相同长度及相同 xref 偏移的一页增量 PDF。9 个版本-场景结果复现了一个受限的兼容性回归信号：AI 候选与漏洞版本接受第二份合法 PDF，维护者修复版本错误地报 trailer loop；三版均处理官方循环 PoV与首份合法链。静态实现显示维护者的共享可变默认列表会跨 `PdfParser` 实例保留偏移，和行为结果一致。V1R3 的重复字节夹具不进入结论；结论依据 V1R4。

这是一个独立 CVE 家族的公开非盲候选观察，不是第二个配置遗漏，也尚未验证 Pillow 高层 API 的真实使用契约或生产影响。完整结果、九项原始观察、门禁重新核验及复现入口见 `02_experiments/runs/ARGD_PILLOW_CVE2026_42310_VALIDATION_EXPLORATORY_20261031_V1R4/evidence/V1R4_RESULT_REPORT_CN.md`。本次不向根结果账本登记，也不作方法优势或发生率主张。


## 2026-10-31 15:00 后续筛查：PatchPorter 官方工件（完成静态资格检查）

官方 Zenodo 工件 10.5281/zenodo.21959756 已下载并以 MD5 与登记值校验一致。112 个目录仅提供漏洞元数据、上游修复差异、待移植输入和 Jest oracle；README 明示不含 API 输出/生成实验结果。路径筛查在上游 `patch.diff` 命中35个广义配置相关路径，但包括 package 元数据/锁文件和测试夹具；清理后的 `final-patch.diff` 命中0个配置路径。没有生成的 LLM 候选可与上游修复配对，因此不具备新遗漏行为实验资格。未克隆上游项目、未运行工具、未调用模型。校验与结论见 `sources\PATCHPORTER_STATIC_SCREEN_CN.md`；工件 SHA-256 `B43C8AC8D39F3B3E43B390B2C557E06B949E3030B127F0BCB8BCC978C098F230`。


## 2026-10-31 15:11 后续筛查：PatchEval 已有模型输出与 V6/SAP 交叉

PatchEval 本地来源清单中，5 份模型 JSON 通过 Git blob SHA/字节数核验，合计覆盖230个唯一 CVE；其中模型输出 diff 未发现配置文件路径改动。和冻结 V6/SAP 配置路径清单50个 CVE 的交集为0。GPT-4.1 档案长度及哈希不匹配，另外4份模型文件缺失，均不纳入结论。已有 agent 日志的18条运行时配置路径记录涉及12个 CVE，与其参考修复路径无同路径命中，且记录多为 fail。没有匹配的候选配置遗漏，不启动行为实验。详情见 `PATCHEVAL_MODEL_OUTPUT_SCREEN_CN.md`；来源明细仍在 `source_artifacts\patcheval_mackfork\`。

P2Patch 官方文档称505次运行档案另行分发；本轮重新请求其正式 Figshare 短链接，服务返回 HTTP 202 并附 `x-amzn-waf-action: challenge`，仍无法读取/下载档案。该来源继续标为“未筛查”，不并入分母。

## 2026-10-31 15:42 追加来源筛查

ActiveMQ 上游补丁路径核查排除了该 CVE 作为生产配置文件遗漏案例的资格；唯一 XML 改动是测试资源。其 GPT-5.5 运行包本地下载不完整，未用于候选补丁分析。VulnBench 是公开模型补丁来源，但许可状态未解决，且结果为 LLM judge 评审而非执行验证；本轮不获取/执行其补丁。两份筛查说明见本目录 `FLAWED_ACTIVEMQ_CONFIG_PATH_SCREEN_CN.md` 和 `VULNBENCH_PUBLIC_SOURCE_STATUS_CN.md`。截至该时点仍无 VUL4J-32 之外的确认配置遗漏案例。

## 2026-10-31 15:50 追加筛查：执行校准补丁档案

补筛此前已取得的执行校准补丁包：Tier-1 的 66 个真实 JavaScript CVE 与冻结配置路径 CVE 集无交集；两套多语言可执行补丁是 CWE 场景；Tier-2 Java 真实 CVE 集中唯一命中仍为 VUL4J-32。该来源没有提供第二个身份独立配置遗漏候选。详情见本目录 `EXECUTION_CALIBRATED_PATCH_REPRO_SCREEN_CN.md`。没有新运行实验。
## 2026-10-31 15:57 追加筛查：P2Patch 官方参考修复

P2Patch 仓库 101 项 benchmark 对应的公开修复材料中，筛查了 119 份 `official_fix.patch`（`fix_povs` 97 份、`residual_povs` 22 份），覆盖 97 个项目目录、210 条新建或修改路径。路径扩展名包括 Java 137、C 63、头文件 6、无扩展名 2，以及 XML 2。两个 XML 路径都是 `pom.xml`，内容仅新增构建依赖：Kylin 的 `kylin-datasource-sdk` 和 Kubernetes Java 客户端的 `commons-io`。另有两处删除路径，均为 Java 文件。未发现生产安全策略或运行时配置文件改动。307 条 `fix_info.csv` 修复定位记录也都指向 Java 文件。

候选运行归档仍无法取得：官方 505-run 压缩包的 Figshare 直链本次访问返回 403/WAF challenge。官方 README 和使用指南称归档含候选 diff、运行记录与 verdict；本轮未检查候选补丁输出。故 P2Patch 仅完成公开参考修复的静态来源筛查，不构成模型补丁实验阴性，也不计科学样本。证据快照和可复现脚本见 `P2PATCH_SOURCE_SCREEN_CN.md` 与 `source_artifacts/p2patch_reference_snapshot/`。

本轮仍未发现 VUL4J-32 之外身份独立、可复现的生产配置遗漏案例。十小时授权窗口截至 16:33；窗口内继续检查未重复筛查的合格来源，之后完成总报告及权威状态文件收尾。V6/SAP 冻结范围、门槛与既有证据保持不变。

## 2026-10-31 16:04 追加筛查：CVE-Bench AI 修补档案

本地已有的 CVE-Bench AI 修补归档固定于上游 commit `45cb1bf72f034eace43e46a9ae131c53a7fd292b`，静态检查其 9 个 CVE 对应的 130 个派生补丁文件和 9 份任务参考 `fix.patch`。派生补丁的 244 条路径记录中，228 条为 Python、6 条为 Markdown、1 条为 Pillow 的 `pytest.ini`，9 条路径记作 `?` 而无法定位到项目文件。九份参考修复共 21 条路径（18 条 Python、3 条 Markdown）；其 SHA-256 均与原归档清单相符，未发现生产安全配置变更。

因此这组材料不包含候选补丁遗漏生产安全配置的匹配对象。它是跨项目已有工件的来源资格核查，不是新行为实验；没有重跑旧样本、测试或模型。归档原说明要求这些已接触样本不得作为新的泛化成绩，本轮遵守该边界。详见 `CVE_BENCH_AI_REPAIR_STATIC_CONFIG_SCREEN_CN.md`。

截至 16:04，本轮新增的 P2Patch 与 CVE-Bench 来源筛查均未产生第二个配置遗漏案例。探索授权窗口截至 16:33；后续只处理仍未筛查且能与候选输出及上游生产配置修复配对的来源，之后冻结完整探索报告。

## 2026-10-31 16:23 后续来源筛查：SEC-bench

官方 `SEC-bench/experiments` 固定提交的候选输出被稀疏检出并逐项核验：1,192 份候选 diff 对应参考集 `eval` split 的 300 个任务 ID，全部身份匹配；共 1,167 个模型—任务组合。参考集固定 HF revision `11422e774857272b8f5460c699dca7a64046308b`，300 项均为 C++，300 个上游修复的改动路径中没有生产运行时配置路径。94 份候选补丁包含配置命名头文件的修改，但这些路径均未出现在对应参考修复中。因此该来源具备公开 AI 候选工件，但不具备本轮配置遗漏主张的参考修复对象；没有筛选原测试通过候选或执行行为测试，不计科学阴性。复核报告与哈希清单见 `SECBENCH_EXPERIMENTS_SOURCE_SCREEN_CN.md`。

## 2026-10-31 16:32 后续资格核查：Zero-Shot Vulnerability Repair / ExtractFix

Zenodo 10.5281/zenodo.7199939 只列出一个 11.1 GB 的 Data.zip，未列出单独的结果/清单文件；文件下载端点拒绝仅请求 Range 的读取（HTTP 403），因此没有下载或检查压缩包内部候选。论文第 V-B 节及 Table VI 列出的 12 个真实案例均为 libtiff、libxml2、libjpeg-turbo 的 C 源文件，案例筛选条件要求开发者补丁限于单文件。该来源不具备本轮所需的生产配置修复对象资格；此结论是来源筛查，不是候选行为负例。详见 `sources\ZERO_SHOT_EXTRACTFIX_SOURCE_SCREEN_CN.md`。
## 十小时探索收尾（2026-10-31 16:33，北京时间）

授权窗口内完成了对新增公开来源的资格筛查与既有结果复核；未发现 VUL4J-32 之外的独立生产配置遗漏案例。新增筛查覆盖 SEC-bench、PatchEval、PatchPorter、P2Patch、CVE-Bench、Vul4Py、Zero-Shot/ExtractFix 等来源；来源无法读取、候选不完整或参考修复不含生产配置路径的情况均保持为“未纳入/不合格来源”，没有当作模型阴性。没有因不合格线索启动行为实验，没有改变 V6/SAP 冻结总体、分类规则或阈值。

本窗口内没有新的行为实验正在执行。可报告的跨案例正向观察仍包括：VUL4J-32 的配置遗漏对照；libtiff 公开候选通过已知安全 PoV 与 74/74 功能测试；Pillow V1R4 的单候选兼容性回归信号。后两者不计作配置遗漏，Pillow 的真实产品契约与影响仍待独立核查。完整过程和证据边界见本报告及 `EXPLORATION_LOG_CN.md`。