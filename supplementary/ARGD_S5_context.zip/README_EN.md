> Public release copy, prepared on 8 November 2026. Machine-local workspace roots in this copy use `PUBLIC_PATH_REDACTED/`. Original source identities and numerical observations are retained. Historical byte-preservation statements below describe the retained submission source. The public-copy file hashes are listed in this archive's manifest and in the repository publication records. Consult `PUBLICATION_PROVENANCE.md` in the repository for the public-copy scope.

# R21 contextual observations

These heterogeneous studies are not a common effectiveness matrix. AntiSamy: 240 measurement records in one CVE, with 80 earlier overlapping records counted only once. The XML-factor pattern is supported in 10 of 12 policy/parser combinations; Tinymce already blocks the attack. Four legitimate-input href removals lack a separately fixed policy contract. The derived observation table omits encoded inputs and output HTML; source hashes in the evidence index identify original CSVs. A separate accounting script is not a second researcher's blind review.

libtiff: one public candidate passed its known security PoV and 74/74 functional tests. This is a positive result for executed checks, not an omission. Its neighboring branch produced no scientific observation. The original report states the independent-review limitation.

Pillow: nine version/scenario observations identify a limited low-level parser compatibility signal. High-level API contract and production impact remain unverified. The original historical gate readback is absent. The documented later gate recheck does not substitute for it.

Source screening: the primary 972 records and SAP 920 records preserve classified, pending, unresolved, not-attempted and invalid-ID states. The included crossmatch summary is a derived frozen snapshot; its hashes identify the original WSL BATCH_RESULT files, which were not reopened in this editorial revision. The 5% decision is unresolved. Source ineligibility, unavailable artifacts and setup failures are not scientific negatives.

The exploration report is an append-only historical record. Its early description of Recovery3 as official PoV/regression testing must be interpreted as the custom adapter; S3 and the main text give the native 0/7 result. Earlier 'no experiment' statements refer to their original timestamps.

This addendum redistributes documentation and numerical results only. Candidate patches, PoV files and experimental drivers remain at their governed original sources and are not newly copied or executed.
