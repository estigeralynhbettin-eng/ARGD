"""R24 compact evaluator figure from portable retained R23 CSVs.

Run: PUBLIC_PATH_REDACTED/python_utf8.ps1 tools/plot_fig6_compact.py
Only reads the bound figure tables, with no experiment or model execution.
No absolute skill path, D-drive read, network call or runtime benchmark needed.
"""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import json
import sys
import warnings

sys.dont_write_bytecode = True
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib import font_manager
import fitz
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'plot_data'
OUT = ROOT / 'figures'
QA = ROOT / 'qa'
WIDTH_MM, HEIGHT_MM = 145.0, 62.0
INSERT_WIDTH_MM = 147.2
CONFIGS = ['claude', 'deepseek', 'glm', 'qwen', 'qwen35_9b', 'qwen35_27b']
LABELS = ['Claude', 'DeepSeek', 'GLM', 'Qwen2.5', 'Qwen3.5 9B', 'Qwen3.5 27B']
CONDITIONS = ['llm_only', 'pov_only', 'pov_regression']
BLUE, ORANGE, INK = '#0072B2', '#D55E00', '#242424'


def rows(name):
    with (DATA/name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_csv(name, records):
    with (DATA/name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(records[0]))
        w.writeheader()
        w.writerows(records)


def dump(name, obj):
    (DATA/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def prepare():
    aggregate, records = rows('Fig6_aggregate.csv'), rows('Fig6_records.csv')
    require(len(aggregate) == 18 and len(records) == 576, 'Source row counts')
    require(len({(r['config'],r['condition'],r['candidate_id']) for r in records}) == 576, 'Duplicate records')
    require({r['config'] for r in records} == set(CONFIGS), 'Configuration identities')
    require({r['condition'] for r in records} == set(CONDITIONS), 'Condition identities')
    grouped = {(c,cond): [r for r in records if r['config']==c and r['condition']==cond]
               for c in CONFIGS for cond in CONDITIONS}
    rates, parsing, conservation = [], [], []
    for a in aggregate:
        key = a['config'], a['condition']
        rr = grouped[key]
        require(len(rr)==int(a['n_records'])==32, 'Per-condition conservation')
        strict = sum(int(r['strict_json_valid']) for r in rr)
        recovered = sum(int(r['recovered_only']) for r in rr)
        unparsed = sum(r['historical_category']=='parse_failure' for r in rr)
        eligible = sum(int(r['failure_evidence_eligible']) for r in rr)
        conflict = sum(int(r['strict_conflicting_accept']) for r in rr)
        hist_conflict = sum(int(r['historical_conflicting_accept']) for r in rr)
        require(strict+recovered+unparsed==32, 'Parsing conservation')
        require((strict,recovered,unparsed,eligible,conflict,hist_conflict)==tuple(int(a[k]) for k in
                ['strict_json_valid','recovered_only','historical_parse_failure','failure_evidence_denominator',
                 'strict_conflicting_accept','historical_conflicting_accept']), 'Aggregate-record equality')
        require(eligible=={'llm_only':0,'pov_only':18,'pov_regression':22}[a['condition']], 'Condition denominator')
        conservation.append({'config':a['config'],'condition':a['condition'],'logical_records':len(rr),
                             'strict_json':strict,'recovered_only':recovered,'unparsed':unparsed,
                             'parsing_sum':strict+recovered+unparsed,'failure_evidence_eligible':eligible,
                             'strict_conflicting_accept':conflict,'historical_conflicting_accept':hist_conflict,
                             'conflict_panel_included':a['condition']!='llm_only',
                             'exclusion_reason':'No supplied failure evidence under llm_only' if a['condition']=='llm_only' else '',
                             'source_fields':'Fig6_records strict_json_valid,recovered_only,historical_category,failure_evidence_eligible,strict_conflicting_accept'})
        if a['condition']!='llm_only':
            require(conflict==hist_conflict, 'Strict and historical conflicts differ')
            rates.append({'config':a['config'],'condition':a['condition'],'conflicting_accepts':conflict,
                          'failure_evidence_denominator':eligible,'rate_percent':100*conflict/eligible,
                          'count_label':f'{conflict}/{eligible}',
                          'definition':'Accept despite supplied number_failing or number_error > 0',
                          'denominator_scope':'Only failure evidence supplied in the recorded condition'})
    for c,label in zip(CONFIGS,LABELS):
        rr = [r for r in conservation if r['config']==c]
        model_labels={r['recorded_model_label'] for r in records if r['config']==c}
        require(len(model_labels)==1,'Ambiguous recorded model label')
        row={'config':c,'display_label':label,'recorded_model_label':next(iter(model_labels)),
             'logical_records':sum(r['logical_records'] for r in rr),
             'strict_json':sum(r['strict_json'] for r in rr),'recovered_only':sum(r['recovered_only'] for r in rr),
             'unparsed':sum(r['unparsed'] for r in rr)}
        row['parsing_sum']=row['strict_json']+row['recovered_only']+row['unparsed']
        row['panel_b_bar_included']=row['recovered_only']>0
        row['panel_b_zero_group_annotation']=row['recovered_only']==0
        require(row['logical_records']==row['parsing_sum']==96,'Per-configuration conservation')
        parsing.append(row)
    require(sum(r['strict_json'] for r in parsing)==559,'Strict total')
    require(sum(r['recovered_only'] for r in parsing)==14,'Recovery total')
    require(sum(r['unparsed'] for r in parsing)==3,'Unparsed total')
    require({r['config']:r['recovered_only'] for r in parsing if r['recovered_only']}=={'qwen35_9b':13,'qwen35_27b':1},'Recovery distribution')
    require(all(r['conflicting_accepts']==0 for r in rates if r['config']!='qwen'),'Other configurations')
    require({r['condition']:r['conflicting_accepts'] for r in rates if r['config']=='qwen'}=={'pov_only':2,'pov_regression':6},'Qwen conflicts')
    write_csv('Fig6_compact_conflict_rates.csv',rates)
    write_csv('Fig6_compact_parsing_by_config.csv',parsing)
    write_csv('Fig6_compact_conservation.csv',conservation)
    manifest={'input_files':[{'path':name,'sha256':sha(DATA/name),'bytes':(DATA/name).stat().st_size}
                             for name in ['Fig6_aggregate.csv','Fig6_records.csv','Fig6_source_manifest.json']],
              'raw_provenance_manifest':'Fig6_source_manifest.json',
              'derived_from':'Portable unchanged R23 derived records, whose original raw ZIP provenance remains in the source manifest',
              'panel_a':'All six configurations, pov_only and pov_regression only. llm_only is inapplicable, not a negative conflict result',
              'panel_b':'Across three conditions, 96 logical records per configuration. Plot the two positive recovery counts and explicitly label four zero groups',
              'full_detail_retained':'detail_figures/R23_Fig6.pdf/svg/png and all 576 Fig6_records.csv rows',
              'units':'Logical decision records and condition-specific supplied-failure subsets',
              'error_bars':'None. Descriptive counts without independent trials or inferential uncertainty',
              'new_experiments':0,'new_model_calls':0,'new_network_calls':0}
    dump('Fig6_compact_source_manifest.json',manifest)
    return rates,parsing,conservation


def style():
    try:
        import scienceplots
        plt.style.use(['science','no-latex'])
    except ImportError:
        plt.style.use('default')
    require(font_manager.FontProperties(fname=font_manager.findfont('Times New Roman',fallback_to_default=False)).get_name()=='Times New Roman','TNR unavailable')
    plt.rcParams.update({'font.family':'Times New Roman','font.size':8.5,'axes.labelsize':8.5,
                         'xtick.labelsize':8.5,'ytick.labelsize':8.5,'legend.fontsize':8.5,
                         'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','text.usetex':False,
                         'savefig.bbox':None,'savefig.pad_inches':0,'savefig.dpi':420,
                         'axes.unicode_minus':False,'axes.linewidth':0.55,'grid.linewidth':0.35,
                         'xtick.major.width':0.5,'ytick.major.width':0.5,'xtick.major.size':2.2,
                         'xtick.minor.visible':False,'ytick.minor.visible':False})


def mm(x,y):
    return x/WIDTH_MM,y/HEIGHT_MM


def draw(rates,parsing):
    style()
    fig=plt.figure(figsize=(WIDTH_MM/25.4,HEIGHT_MM/25.4),dpi=150)
    ax=fig.add_axes([29/WIDTH_MM,17/HEIGHT_MM,54/WIDTH_MM,31/HEIGHT_MM])
    lookup={(r['config'],r['condition']):r for r in rates}
    xlim=(-2.5,34.5)
    for index,c in enumerate(CONFIGS):
        y=5-index
        for cond,offset,color,marker in [('pov_only',.16,BLUE,'o'),('pov_regression',-.16,ORANGE,'s')]:
            r=lookup[c,cond]
            # Zero is inside the plot region and every marker is unclipped.
            ax.scatter(r['rate_percent'],y+offset,s=19,color=color,marker=marker,
                       edgecolor=color,linewidth=.6,zorder=3,clip_on=False)
            if r['conflicting_accepts']:
                ax.annotate(r['count_label'],(r['rate_percent'],y+offset),xytext=(4,0),textcoords='offset points',
                            ha='left',va='center',fontsize=8.5,color=INK)
        if c!='qwen':
            ax.text(2.25,y,'0',ha='left',va='center',fontsize=8.5,color=INK)
    ax.set_xlim(*xlim);ax.set_ylim(-.55,5.55)
    ax.set_yticks(range(5,-1,-1),LABELS)
    ax.set_xticks([0,10,20,30],['0','10','20','30'])
    ax.set_xlabel('Conflicting accepts (%)',labelpad=3)
    ax.tick_params(axis='y',length=0,pad=3,left=False,right=False)
    ax.tick_params(axis='x',top=False,bottom=True,direction='out')
    ax.spines[['top','right','left']].set_visible(False)
    ax.axvline(0,color='#C5C5C5',lw=.45,zorder=0)
    ax.grid(axis='x',color='#D6D6D6',lw=.35,alpha=.8)
    ax.set_axisbelow(True)
    fig.text(*mm(2,58.5),'(a) Accepts despite failures',fontsize=9,ha='left',va='center')
    handles=[Line2D([],[],marker='o',ls='',color=BLUE,markersize=4,label='PoV (n=18)'),
             Line2D([],[],marker='s',ls='',color=ORANGE,markersize=4,label='PoV + reg. (n=22)')]
    fig.legend(handles=handles,loc='center',bbox_to_anchor=mm(46,52.5),frameon=False,ncol=2,
               handletextpad=.4,columnspacing=.9,borderpad=0)
    fig.text(*mm(91.5,58.5),'(b) Parsing recovery',fontsize=9,ha='left',va='center')
    fig.text(*mm(91.5,52.5),'14 of 576 records',fontsize=8.5,ha='left',va='center')
    axb=fig.add_axes([115/WIDTH_MM,26/HEIGHT_MM,27/WIDTH_MM,19/HEIGHT_MM])
    nonzero=[r for r in parsing if r['recovered_only']]
    for y,row in [(1,nonzero[0]),(0,nonzero[1])]:
        axb.barh(y,row['recovered_only'],height=.34,color='#707070',edgecolor=INK,linewidth=.45)
        axb.text(row['recovered_only']+.45,y,str(row['recovered_only']),ha='left',va='center',fontsize=8.5)
    axb.set_xlim(0,15.5);axb.set_ylim(-.55,1.55)
    axb.set_yticks([1,0],['Qwen3.5 9B','Qwen3.5 27B'])
    axb.set_xticks([0,5,10,15])
    axb.set_xlabel('Recovered decisions',labelpad=3)
    axb.tick_params(axis='y',length=0,pad=3,left=False,right=False)
    axb.tick_params(axis='x',direction='out',top=False)
    axb.spines[['top','right','left']].set_visible(False)
    fig.text(*mm(91.5,13),'Other four configurations: 0',fontsize=8.5,ha='left',va='center')
    fig.text(*mm(72.5,3.2),'576 records = 559 strict JSON + 14 recovered + 3 unparsed',
             fontsize=8.5,ha='center',va='center')
    return fig,ax,axb


def check_layout(fig,ax,axb):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        fig.canvas.draw()
    require(not any('Glyph' in str(w.message) and 'missing' in str(w.message) for w in caught),'Missing font glyph')
    renderer=fig.canvas.get_renderer()
    bounds=fig.bbox
    issues=[]
    texts=[]
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text().strip():continue
        b=text.get_window_extent(renderer)
        if b.width<=0 or b.height<=0:continue
        if b.x0<bounds.x0-.5 or b.y0<bounds.y0-.5 or b.x1>bounds.x1+.5 or b.y1>bounds.y1+.5:
            issues.append({'type':'text_outside_canvas','text':text.get_text(),'bbox':list(b.bounds)})
        texts.append((text,b))
    for axis in [ax,axb]:
        labels=axis.get_xticklabels()
        for a,b in zip(labels,labels[1:]):
            if a.get_window_extent(renderer).overlaps(b.get_window_extent(renderer)):
                issues.append({'type':'tick_overlap','labels':[a.get_text(),b.get_text()]})
    # A small positive axis margin keeps complete marker circles/squares at x=0.
    zero_x=ax.transData.transform((0,0))[0]
    zero_margin_px=zero_x-ax.get_window_extent(renderer).x0
    marker_radius_px=(19**.5)*fig.dpi/72/2
    require(zero_margin_px>marker_radius_px,'Zero markers may be clipped')
    require(min(t.get_fontsize() for t,_ in texts)>=8,'Minimum font')
    require(not any(';' in t.get_text() or '；' in t.get_text() for t,_ in texts),'Semicolon in figure')
    require(not issues,'Layout issues: '+str(issues))
    return {'issues':issues,'text_artists':len(texts),'minimum_font_pt':min(t.get_fontsize() for t,_ in texts),
            'zero_margin_pixels':zero_margin_px,'marker_radius_pixels':marker_radius_px,
            'zero_marker_inside_axis':True,'panel_title_baselines_mm':[58.5,58.5],
            'font_at_insertion_min_pt':min(t.get_fontsize() for t,_ in texts)*INSERT_WIDTH_MM/WIDTH_MM}


def export(fig,layout):
    for suffix in ['pdf','svg','png']:
        fig.savefig(OUT/f'Fig6.{suffix}',dpi=420,bbox_inches=None,pad_inches=0)
    # True 96 dpi physical-size previews for local color and grayscale checks.
    fig.savefig(DATA/'Fig6_compact_actual_size_color.png',dpi=96,bbox_inches=None,pad_inches=0)
    with Image.open(DATA/'Fig6_compact_actual_size_color.png') as im:
        ImageOps.grayscale(im).save(DATA/'Fig6_compact_actual_size_grayscale.png',dpi=(96,96))
    with fitz.open(OUT/'Fig6.pdf') as pdf:
        page=pdf[0]
        actual_mm=[page.rect.width*25.4/72,page.rect.height*25.4/72]
        fonts=[]
        for f in page.get_fonts(full=True):
            extracted=pdf.extract_font(f[0])
            fonts.append({'xref':f[0],'name':f[3],'type':f[2],'embedded_bytes':len(extracted[3])})
        sizes=[span['size'] for block in page.get_text('dict')['blocks'] if 'lines' in block
               for line in block['lines'] for span in line['spans'] if span['text'].strip()]
        require(all(f['embedded_bytes']>0 and f['type']!='Type3' for f in fonts),'Unembedded font')
        require(not page.get_images(),'PDF raster image')
        require(abs(actual_mm[0]-WIDTH_MM)<.01 and abs(actual_mm[1]-HEIGHT_MM)<.01,'Physical dimensions')
        require(55<=actual_mm[1]<=65 and actual_mm[1]<=68,'Height limit')
        require(min(sizes)>=8,'PDF minimum font')
    svg=(OUT/'Fig6.svg').read_text(encoding='utf-8')
    require('<text' in svg and '<image' not in svg,'SVG must retain vector text')
    with Image.open(OUT/'Fig6.png') as im:
        pixel_size=list(im.size);dpi=list(im.info['dpi'])
    return {'physical_mm':actual_mm,'intended_insert_width_mm':INSERT_WIDTH_MM,
            'pdf_minimum_font_pt':min(sizes),'fonts':fonts,'pdf_raster_images':0,
            'svg_live_text':True,'svg_raster_images':0,'png_pixels':pixel_size,'png_dpi':dpi,
            'artifacts':{f'Fig6.{s}':sha(OUT/f'Fig6.{s}') for s in ['pdf','svg','png']},
            'layout':layout,'visual_review':'PENDING_LOCAL_IMAGE_INSPECTION'}


def report(checks):
    text='''# Fig6 紧凑重画与核验

主图将比较重点收敛到两项可见差异：给定失败证据后仍接受的建议，以及历史宽松解析恢复的记录。R23完整18条分布和全部576条记录继续保留在S6材料与detail_figures中。

## 图约定与守恒

- 成图145×62 mm，插入宽147.2 mm。Times New Roman常规8.5–9 pt，实际最小8.5 pt，插入后约8.63 pt。主面板使用统一百分比轴，六配置各有PoV与PoV加回归两个点。分母分别为18与22。无测试条件没有已提供失败证据，因此不进入冲突图，也不当作冲突阴性。
- Qwen2.5的冲突接受为2/18和6/22，其余五配置在这两条件下均0。零点有轴内留白并完整显示，以圆点和方块冗余区分证据条件。
- 解析面板聚合全部三条件，每配置96条。576=559严格JSON可读+14仅宽松恢复+3仍不可解析。恢复分布只有Qwen3.5 9B的13条和27B的1条，图中明确注明另四配置为0。完整六配置守恒表没有删组。
- 无误差线或显著性检验。这是归档逻辑记录的描述性比较，不能解释为独立补丁统计或匹配的模型能力排名。标记计数与建议正确性分开。

## 来源与程序检查

脚本只读包内Fig6_aggregate.csv、Fig6_records.csv和Fig6_source_manifest.json，不读取D盘、不运行实验、扫描、网络或模型。输入表保持原字节。脚本没有skill绝对路径依赖。

输出Fig6_compact_conflict_rates.csv保存12个配置/证据条件组合，Fig6_compact_parsing_by_config.csv保存全部六配置，Fig6_compact_conservation.csv保留18组×32=576记录的逐组核对，并明确无测试条件被排除的原因。Fig6_compact_source_manifest.json保存输入哈希和变换定义。Fig6_compact_checks.json保存尺寸、字体、嵌入、边界、零点、导出哈希等检查。PDF/SVG均为矢量，PNG为420 dpi。

## 视觉核查

VISUAL_REVIEW_TEXT

图内使用短名。其对应的归档配置完整标签为Claude-Opus-4.8、DeepSeek-v4-pro、GLM-5.2、Qwen2.5-Coder-7B-local、Qwen3.5-9B-local和Qwen3.5-27B-Q4KM-local，逐项保存在Fig6_compact_parsing_by_config.csv。短名不表示模型当前在线版本或匹配条件下的性能排名。

## 建议短图注

EN: Conflicting accepts under supplied failure evidence and permissive parsing recovery. Conflict denominators are 18 for PoV and 22 for PoV plus regressions per configuration. Parsing totals cover all 576 records.

CN: 所提供证据含有失败时的冲突接受与宽松解析恢复。每种配置的PoV及PoV加回归冲突分母分别为18和22，解析汇总涵盖全部576条记录。

## 4.8中随新图调整的叙述

EN: Figure 6 highlights the two differences in the archive. Qwen2.5 accepts 2 of 18 cases with supplied PoV failures and 6 of 22 with supplied PoV or regression failures, while the other configurations record zero conflicts in those subsets. Across all conditions, strict JSON parses 559 records directly, permissive recovery adds 14, and three remain unparsed. Thirteen recoveries occur in Qwen3.5 9B and one in Qwen3.5 27B. S6 retains all 576 records and the complete decision distributions.

CN: 图6突出归档中的两项差异。提供PoV失败证据时，Qwen2.5仍接受18例中的2例。提供PoV或回归失败证据时，仍接受22例中的6例，其余配置在这两个子集中均无冲突接受。汇总全部条件后，严格JSON可直接解析559条，宽松规则另恢复14条，3条仍无法解析。13条恢复来自Qwen3.5 9B，1条来自Qwen3.5 27B。S6保留全部576条记录及完整判断分布。

正文原有187/379/7/3与186/366/7/17两套建议计数仍可保留，但不要再写“图6展示完整建议分布”。将该表述改为图6突出冲突与恢复，完整分布见S6。17条严格解析失败分解为14条可宽松恢复加3条仍不可解析，不得称17条全部缺失。
'''
    if isinstance(checks['visual_review'],dict):
        visual='已读取最终420 dpi主图、96 dpi真实物理尺寸彩色图及灰度图。字号在实际尺寸下可读，圆点/方块在灰度下可辨。Qwen2.5的两个冲突点及13/1恢复差异清楚，图例与数据分离，两面板标题同基线，零点完整，无裁切、重叠、乱码或分号。程序检查与本地视觉检查均PASS。'
    else:
        visual='待读取实际96 dpi彩色及灰度图后补录。程序检查无文字越界或刻度重叠，零点在轴边界内，图中没有分号。'
    (QA/'Fig6_COMPACT_QA_CN.md').write_text(text.replace('VISUAL_REVIEW_TEXT',visual),encoding='utf-8')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--confirm-local-visual-review',action='store_true',
                        help='Record a completed human/agent local inspection of the unchanged color and grayscale rendering')
    args=parser.parse_args()
    rates,parsing,conservation=prepare()
    fig,ax,axb=draw(rates,parsing)
    layout=check_layout(fig,ax,axb)
    checks=export(fig,layout)
    checks.update({'input_logical_records':576,'parsing_totals':{'strict_json':559,'recovered_only':14,'unparsed':3},
                   'per_configuration_records':96,'records_in_two_failure_evidence_conditions':384,
                   'failure_evidence_eligible_records_in_conflict_subsets':240,
                   'no_failure_evidence_condition_records_excluded':192,
                   'conflict_subsets':{'pov_only':18,'pov_regression':22},
                   'new_experiments':0,'new_model_calls':0,'new_network_calls':0})
    if args.confirm_local_visual_review:
        checks['visual_review']={'status':'PASS_LOCAL_COLOR_GRAYSCALE_AND_ACTUAL_SIZE_INSPECTION',
                                 'full_resolution_color':'figures/Fig6.png',
                                 'actual_size_color':'plot_data/Fig6_compact_actual_size_color.png',
                                 'actual_size_grayscale':'plot_data/Fig6_compact_actual_size_grayscale.png',
                                 'inspection_dpi':96,'rounds':1,
                                 'checks':['Readable at final physical size','No cropping or text overlap',
                                           'Legends separate from data','Circle and square distinguish conditions in grayscale',
                                           'Zero markers fully visible','Panel labels aligned','All six configurations represented',
                                           'Complete 559+14+3 parsing accounting explicit']}
    dump('Fig6_compact_checks.json',checks)
    report(checks)
    plt.close(fig)
    print(json.dumps(checks,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
