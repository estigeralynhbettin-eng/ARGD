"""Redraw the compact Fig4 from the included, unchanged 240-cell table."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os
import platform
import sys
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR'] = str(ROOT / 'qa' / 'fig4_mpl_cache')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.dont_write_bytecode = True
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.text import Text
import numpy as np
from PIL import Image, ImageOps
import scienceplots
from _fig4_visual_qa import audit_layout

MM = 1 / 25.4
WIDTH_MM = 145
HEIGHT_MM = 60
INSERT_WIDTH_MM = 147.2
BLUE = '#0072B2'
VERMILION = '#D55E00'
DARK = '#30363B'
POLICIES = ('antisamy.xml', 'antisamy-ebay.xml', 'antisamy-anythinggoes.xml',
            'antisamy-myspace.xml', 'antisamy-slashdot.xml', 'antisamy-tinymce.xml')
LABELS = ('Default', 'eBay', 'Anything Goes', 'MySpace', 'Slashdot', 'TinyMCE')
ARMS = {'A1_old_java_old_xml': ('old', 'old'),
        'A2_fixed_java_old_xml': ('fixed', 'old'),
        'A3_old_java_fixed_xml': ('old', 'fixed'),
        'A4_fixed_java_fixed_xml': ('fixed', 'fixed')}
INPUTS = ('issue10', 'onsite_1', 'onsite_2', 'onsite_3', 'onsite_4')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def aggregate(source, output):
    with source.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    before = sha(source)
    expected = {(a, p, r, i) for a in ARMS for p in POLICIES for r in ('DOM', 'SAX') for i in INPUTS}
    keys = [(r['arm'], r['policy'], r['parser'], r['input_id']) for r in rows]
    if len(rows) != 240 or len(set(keys)) != 240 or set(keys) != expected:
        raise ValueError('The complete 240-cell Cartesian product is required')
    groups = defaultdict(list)
    for r in rows:
        java, xml = ARMS[r['arm']]
        expected_semantic = 'javascript_marker' if r['input_id'] == 'issue10' else 'legitimate_href'
        value = int(r['predicate_present'])
        state = ('marker_retained' if value else 'marker_absent') if expected_semantic == 'javascript_marker' else ('href_retained' if value else 'href_removed')
        if value not in (0, 1) or r['semantic'] != expected_semantic or r['display_state'] != state:
            raise ValueError('Predicate, semantic, and display state must agree')
        groups[(r['policy'], xml, r['input_id'])].append((java, r['parser'], value))
    group_audit = []
    for (policy, xml, inp), items in groups.items():
        if len(items) != 4 or {(j, p) for j, p, v in items} != {(j, p) for j in ('old', 'fixed') for p in ('DOM', 'SAX')}:
            raise ValueError('Each collapsed group must contain exactly four distinct conditions')
        if len({v for j, p, v in items}) != 1:
            raise ValueError('A condition differs, so this group must not be collapsed')
        group_audit.append({'policy': policy, 'xml_state': xml, 'input_id': inp,
                            'cell_count': 4, 'predicate_present': items[0][2],
                            'all_four_conditions_identical': True})
    summary = []
    for policy in POLICIES:
        for xml in ('old', 'fixed'):
            value = groups[(policy, xml, 'issue10')][0][2]
            summary.append({'panel': 'a', 'semantic': 'javascript_marker', 'policy': policy,
                            'xml_state': xml, 'input_id': 'issue10', 'predicate_present': value,
                            'display_state': 'marker_retained' if value else 'marker_absent',
                            'represented_cells': 4, 'denominator_cells': 4,
                            'distinct_condition_count': 4, 'conditions_agree': True,
                            'condition_definition': '2 Java versions x DOM/SAX'})
    href = [r for r in rows if r['semantic'] == 'legitimate_href']
    removed = [r for r in href if r['predicate_present'] == '0']
    counts = Counter(int(r['predicate_present']) for r in href)
    if counts != {1: 188, 0: 4}:
        raise ValueError('Legitimate href conservation differs from the audited data')
    if {(r['policy'], ARMS[r['arm']][1], r['input_id']) for r in removed} != {('antisamy-tinymce.xml', 'old', 'onsite_4')}:
        raise ValueError('The four removals have a different source identity')
    for value, n in ((1, 188), (0, 4)):
        summary.append({'panel': 'b', 'semantic': 'legitimate_href',
                        'policy': 'all' if value else 'antisamy-tinymce.xml',
                        'xml_state': 'both' if value else 'old',
                        'input_id': 'onsite_1 to onsite_4' if value else 'onsite_4',
                        'predicate_present': value,
                        'display_state': 'href_retained' if value else 'href_removed',
                        'represented_cells': n, 'denominator_cells': 192,
                        'distinct_condition_count': '' if value else 4,
                        'conditions_agree': '' if value else True,
                        'condition_definition': 'all legitimate-input cells' if value else '2 Java versions x DOM/SAX'})
    with output.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0]))
        w.writeheader()
        w.writerows(summary)
    if sum(r['represented_cells'] for r in summary) != len(rows):
        raise ValueError('Summary must conserve all 240 cells')
    marker = [r for r in rows if r['semantic'] == 'javascript_marker']
    transitions = Counter((groups[(p, 'old', 'issue10')][0][2], groups[(p, 'fixed', 'issue10')][0][2]) for p in POLICIES)
    if transitions != {(1, 0): 5, (0, 0): 1}:
        raise ValueError('The policy transition summary differs')
    audit = {'status': 'PASS_EXACT_AGGREGATION', 'source': 'plot_data/Fig4_cells.csv',
             'source_sha256_before': before, 'source_sha256_after': sha(source),
             'source_table_unchanged': before == sha(source), 'source_rows': len(rows),
             'unique_condition_keys': len(set(keys)), 'missing_keys': 0, 'duplicate_keys': 0,
             'condition_product': {'java_xml_arms': 4, 'policies': 6, 'parsers': 2, 'inputs': 5},
             'collapsed_groups': len(groups), 'group_size': 4,
             'all_60_policy_xml_input_groups_identical_across_four_conditions': True,
             'collapsed_marker_points': 12, 'marker_cells': len(marker),
             'marker_present_cells': sum(int(r['predicate_present']) for r in marker),
             'marker_absent_cells': sum(1 - int(r['predicate_present']) for r in marker),
             'present_to_absent_policies': 5, 'absent_to_absent_policies': 1,
             'href_cells': len(href), 'href_retained_cells': counts[1], 'href_removed_cells': counts[0],
             'summary_rows': len(summary), 'summary_represented_cells': 240,
             'summary_source': 'plot_data/Fig4_compact_summary.csv',
             'summary_sha256': sha(output), 'four_condition_group_checks': group_audit,
             'removed_href_cell_keys': [{k: r[k] for k in ('arm', 'policy', 'parser', 'input_id', 'source_line', 'clean_html_sha256')} for r in removed],
             'uncertainty': 'No statistical uncertainty is estimated because conditions are distinct configurations, not independent repeated trials',
             'limits': ['Marker absence in sanitized output does not establish browser exploit prevention',
                        'The allowed-href policy contract for the four removals has not been independently established',
                        'The complete 240-cell view remains in S6 and source observations are not discarded'],
             'original_source_paths_opened': 0, 'network_calls': 0, 'new_experiments': 0}
    return summary, audit


def create_figure(summary):
    plt.style.use(['science', 'no-latex'])
    available = {f.name for f in font_manager.fontManager.ttflist}
    family = next((f for f in ('Times New Roman', 'Liberation Serif', 'DejaVu Serif') if f in available), 'DejaVu Serif')
    plt.rcParams.update({'font.family': family, 'font.size': 8.5,
                         'axes.labelsize': 8.5, 'axes.titlesize': 9,
                         'xtick.labelsize': 8.5, 'ytick.labelsize': 8.5,
                         'legend.fontsize': 8.5, 'text.usetex': False,
                         'axes.unicode_minus': False, 'pdf.fonttype': 42,
                         'ps.fonttype': 42, 'svg.fonttype': 'none',
                         'savefig.dpi': 420, 'savefig.bbox': None,
                         'hatch.linewidth': 0.5})
    fig = plt.figure(figsize=(WIDTH_MM * MM, HEIGHT_MM * MM))
    fig.text(4 / WIDTH_MM, 56.6 / HEIGHT_MM, '(a) Tested JavaScript marker', fontsize=9, va='center')
    fig.text(102 / WIDTH_MM, 56.6 / HEIGHT_MM, '(b) Legitimate href', fontsize=9, va='center')
    handles = [Line2D([], [], marker='s', linestyle='none', color=VERMILION, markersize=5.4, label='Old XML'),
               Line2D([], [], marker='o', linestyle='none', color=BLUE, markersize=5.4, label='Fixed XML')]
    fig.legend(handles=handles, loc='center', bbox_to_anchor=(61 / WIDTH_MM, 50.9 / HEIGHT_MM),
               ncol=2, frameon=False, handletextpad=.4, handlelength=.9, columnspacing=1.35)
    ax = fig.add_axes([28 / WIDTH_MM, 12.8 / HEIGHT_MM, 64 / WIDTH_MM, 34.4 / HEIGHT_MM])
    marker_rows = {(r['policy'], r['xml_state']): r for r in summary if r['panel'] == 'a'}
    for i, policy in enumerate(POLICIES):
        y = 5 - i
        old = marker_rows[(policy, 'old')]['predicate_present']
        fixed = marker_rows[(policy, 'fixed')]['predicate_present']
        offset = .19 if old == fixed else 0
        ax.plot([old, fixed], [y + offset, y - offset], color='#767C80', linewidth=.85, zorder=1)
        ax.scatter(old, y + offset, marker='s', s=29, c=VERMILION, edgecolors=VERMILION, linewidths=.5, zorder=3)
        ax.scatter(fixed, y - offset, marker='o', s=29, c=BLUE, edgecolors=BLUE, linewidths=.5, zorder=4)
    ax.set(xlim=(-.2, 1.2), ylim=(-.5, 5.5))
    ax.set_yticks(range(6), LABELS[::-1])
    ax.set_xticks((0, 1), ('Absent (0)', 'Present (1)'))
    ax.minorticks_off()
    ax.grid(axis='x', color='#D9DDE0', linewidth=.55, zorder=0)
    ax.tick_params(axis='both', which='both', length=0, pad=4, top=False, right=False)
    for spine in ax.spines.values():
        spine.set_visible(False)
    # Composition retains its exact 188:4 geometry rather than magnifying four removals.
    right = fig.add_axes([102 / WIDTH_MM, 9 / HEIGHT_MM, 39 / WIDTH_MM, 43.5 / HEIGHT_MM])
    right.set(xlim=(0, 192), ylim=(0, 1))
    right.axis('off')
    right.text(0, .89, '188/192 retained', va='center', fontsize=8.5)
    right.add_patch(Rectangle((0, .665), 188, .135, facecolor='#B8C0C6', edgecolor=DARK, linewidth=.55))
    right.add_patch(Rectangle((188, .665), 4, .135, facecolor='#F5F5F5', edgecolor=DARK, linewidth=.55, hatch='////'))
    right.annotate('4/192 removed', xy=(190, .662), xytext=(192, .535),
                   ha='right', va='center', fontsize=8.5,
                   arrowprops={'arrowstyle': '-', 'color': DARK, 'linewidth': .65})
    right.text(0, .39, 'All four removals:', va='center', fontsize=8.5)
    right.text(0, .285, 'TinyMCE + old XML', va='center', fontsize=8.5)
    right.text(0, .18, 'onsite_4, 2 Java × DOM/SAX', va='center', fontsize=8.5)
    right.text(0, .04, 'Policy contract unresolved', va='center', fontsize=8.5, color=DARK)
    fig.text(.5, 2.2 / HEIGHT_MM,
             'Each XML point summarizes four identical marker states (2 Java versions × DOM/SAX).',
             ha='center', va='center', fontsize=8.5)
    return fig, family


def check_export(fig, family, out, audit):
    figures = out / 'figures'
    qa = out / 'qa'
    issues = audit_layout(fig)
    for severity, message in issues:
        if severity in ('FAIL', 'WARN'):
            raise ValueError('Layout must pass without warnings: ' + message)
    texts = [t for t in fig.findobj(Text) if t.get_visible() and t.get_text().strip()]
    if any(';' in t.get_text() or '；' in t.get_text() for t in texts):
        raise ValueError('Figure text must not contain semicolons')
    minimum = min(t.get_fontsize() for t in texts)
    if minimum < 8:
        raise ValueError('Final design font size is below the agreed floor')
    for ext in ('pdf', 'svg', 'png'):
        fig.savefig(figures / ('Fig4.' + ext), dpi=420,
                    metadata={'Creator': 'ARGD portable figure script'} if ext in ('pdf', 'svg') else None)
    fig.savefig(qa / 'Fig4_design_size_color.png', dpi=150)
    with Image.open(qa / 'Fig4_design_size_color.png') as im:
        final_width = round(INSERT_WIDTH_MM / 25.4 * 150)
        final = im.convert('RGB').resize((final_width, round(im.height * final_width / im.width)), Image.Resampling.LANCZOS)
        final.save(qa / 'Fig4_final_size_147p2mm_color.png', dpi=(150, 150))
        ImageOps.grayscale(final).save(qa / 'Fig4_final_size_147p2mm_grayscale.png', dpi=(150, 150))
        arr = np.asarray(final, dtype=float) / 255
        matrix = np.array([[.367322, .860646, -.227968], [.280085, .672501, .047413], [-.011820, .042940, .968881]])
        simulated = np.clip(arr @ matrix.T, 0, 1)
        Image.fromarray(np.round(simulated * 255).astype('uint8')).save(qa / 'Fig4_final_size_147p2mm_deuteranopia.png', dpi=(150, 150))
    svg = (figures / 'Fig4.svg').read_text(encoding='utf-8')
    if '<image' in svg:
        raise ValueError('Vector SVG unexpectedly contains a raster image')
    audit['figure'] = {'design_width_mm': WIDTH_MM, 'design_height_mm': HEIGHT_MM,
                       'target_insert_width_mm': INSERT_WIDTH_MM,
                       'target_insert_height_mm': HEIGHT_MM * INSERT_WIDTH_MM / WIDTH_MM,
                       'minimum_design_font_pt': minimum,
                       'minimum_insert_font_pt': minimum * INSERT_WIDTH_MM / WIDTH_MM,
                       'font_family': family, 'layout_issues': issues,
                       'svg_embedded_raster_images': 0,
                       'error_bars': False, 'significance_annotations': False,
                       'old_xml_encoding': 'vermilion square', 'fixed_xml_encoding': 'blue circle',
                       'zero_to_zero_pair': 'TinyMCE uses a small vertical separation so both markers remain visible',
                       'href_bar_counts': [188, 4], 'href_bar_denominator': 192,
                       'png_dpi': 420, 'final_size_previews_dpi': 150,
                       'rendered_text_has_semicolons': False}
    audit['runtime'] = {'python': platform.python_version(), 'matplotlib': matplotlib.__version__,
                        'numpy': np.__version__, 'scienceplots_loaded': True,
                        'platform': platform.system(), 'source_paths_in_table_not_opened': True}
    audit['figure_files'] = [{'path': 'figures/Fig4.' + ext, 'bytes': (figures / ('Fig4.' + ext)).stat().st_size,
                              'sha256': sha(figures / ('Fig4.' + ext))} for ext in ('pdf', 'svg', 'png')]
    write_json(qa / 'Fig4_COMPACT_AUDIT.json', audit)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path, default=ROOT)
    args = parser.parse_args()
    out = args.output_root.resolve()
    for name in ('figures', 'plot_data', 'qa'):
        (out / name).mkdir(parents=True, exist_ok=True)
    source = ROOT / 'plot_data/Fig4_cells.csv'
    summary, audit = aggregate(source, out / 'plot_data/Fig4_compact_summary.csv')
    fig, family = create_figure(summary)
    check_export(fig, family, out, audit)
    plt.close(fig)
    print(json.dumps({'status': audit['status'], 'source_rows': audit['source_rows'],
                      'summary_rows': audit['summary_rows'], 'figure': audit['figure']}, indent=2))


if __name__ == '__main__':
    main()
