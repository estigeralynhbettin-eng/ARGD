#!/usr/bin/env python3
"""Compact Fig3 from packaged R23 records. No project execution or network.

Run from any directory: python tools/plot_fig3_compact.py
Inspect qa/Fig3_compact_preview.png, then rerun with --export.
Dependencies: matplotlib, numpy, Pillow. SciencePlots and PyMuPDF are optional.
The script reads only sibling plot_data files. Original locator strings are
retained as metadata and are never resolved against the local filesystem.
"""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import json
import os
import platform
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA, QA, FIGS = (ROOT / name for name in ('plot_data', 'qa', 'figures'))
for directory in (DATA, QA, FIGS):
    directory.mkdir(parents=True, exist_ok=True)
os.environ['MPLCONFIGDIR'] = str(QA / 'mpl_cache_fig3_compact')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
import numpy as np
from PIL import Image, ImageOps

WIDTH_MM, HEIGHT_MM = 145.0, 58.0
INSERT_WIDTH_MM = 147.2
FONTSIZE = 8.5
COLORS = {'PASS': '#0072B2', 'FAIL': '#D55E00', 'NOT_RUN': '#777777'}
MARKERS = {'PASS': 'o', 'FAIL': 'x', 'NOT_RUN': '_'}
PHASES = ('pov_checker', 'regressions', 'M32-01', 'controls')
PANELS = (
    ('native', '(a) Native checks', 0.0, (
        ('bundled_human_repair', 'Bundled repair'),
        ('same_repair_complete_xml', 'Same repair\n+ complete XML'),
        ('seven_public_candidates', '7 candidates'))),
    ('historical', '(b) Earlier adapter', 73.1, (
        ('vulnerable', 'Vulnerable\n6-input checker'),
        ('complete_developer_repair', 'Full repair\n6-input checker'),
        ('seven_compilable_candidates', '7 candidates\n4-input checker'),
        ('one_uncompilable_candidate', '1 candidate\nbuild failed'))))
X_COLUMNS = (33.5, 44.5, 55.5, 66.5)
Y_ROWS = (36.5, 28.5, 20.5, 12.5)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def file_info(path):
    blob = path.read_bytes()
    return {'file': path.relative_to(ROOT).as_posix(), 'bytes': len(blob),
            'sha256': hashlib.sha256(blob).hexdigest()}


def csv_read(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def json_write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def load_and_validate():
    cells = csv_read(DATA / 'Fig3_plot_cells.csv')
    source = csv_read(DATA / 'Fig3_source_cells.csv')
    require(len(cells) == 28 and len(source) == 76, 'Expected 28 cells from 76 version-phase records')
    expected = {(panel, group, phase) for panel, _, _, groups in PANELS
                for group, _ in groups for phase in PHASES}
    indexed = {(r['panel'], r['group'], r['phase']): r for r in cells}
    require(set(indexed) == expected and len(indexed) == len(cells), 'Missing or duplicate cell')
    for key, row in indexed.items():
        require(row['state'] in COLORS, 'Unknown execution state')
        matching = [(i, r) for i, r in enumerate(source, 2)
                    if tuple(r[k] for k in ('panel', 'group', 'phase')) == key]
        require(len(matching) == int(row['versions']), f'Grouping count differs for {key}')
        for _, raw in matching:
            for src_key, plot_key in (('state', 'state'), ('passed', 'passed_each'),
                                      ('executed', 'executed_each'),
                                      ('fixture_inputs', 'fixture_inputs'),
                                      ('compilation', 'compilation')):
                require(raw[src_key] == row[plot_key], f'Nonidentical grouped values for {key}')
        if row['state'] == 'NOT_RUN':
            require(row['passed_each'] == row['executed_each'] == '', 'Not-run count must remain blank')
        elif row['state'] == 'PASS':
            require(int(row['passed_each']) == int(row['executed_each']), 'Passing cell has failures')
        else:
            require(int(row['passed_each']) < int(row['executed_each']), 'Failure cell lacks a failed test')
        if row['compilation'] == 'BUILD_FAILED':
            require(row['state'] == 'NOT_RUN', 'Build failure cannot become a failed test')
        row['_source_csv_lines'] = '|'.join(str(i) for i, _ in matching)
    require(indexed[('native', 'seven_public_candidates', 'pov_checker')]['versions_passing'] == '0',
            'Native PoV candidate pass count changed')
    require(indexed[('historical', 'seven_compilable_candidates', 'pov_checker')]['versions_passing'] == '7',
            'Earlier checker candidate pass count changed')
    require(indexed[('native', 'seven_public_candidates', 'pov_checker')]['fixture_inputs'] == '6',
            'Native checker input count changed')
    require(indexed[('historical', 'seven_compilable_candidates', 'pov_checker')]['fixture_inputs'] == '4',
            'Earlier checker input count changed')
    return cells, indexed, source


def setup_style():
    scienceplots_used = False
    try:
        import scienceplots  # noqa: F401
        plt.style.use(['science', 'no-latex'])
        scienceplots_used = True
    except ImportError:
        plt.style.use('default')
    plt.rcParams.update({'font.family': 'Times New Roman', 'font.size': FONTSIZE,
                         'axes.unicode_minus': False, 'text.usetex': False,
                         'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
                         'svg.hashsalt': 'ARGD-Fig3-compact-r24',
                         'savefig.bbox': None, 'savefig.pad_inches': 0,
                         'savefig.dpi': 420, 'figure.facecolor': 'white',
                         'axes.facecolor': 'white'})
    font_path = font_manager.findfont(font_manager.FontProperties(family='Times New Roman'),
                                      fallback_to_default=False)
    return scienceplots_used, Path(font_path).name


def make_plot(indexed):
    fig = plt.figure(figsize=(WIDTH_MM / 25.4, HEIGHT_MM / 25.4), dpi=180)
    ax = fig.add_axes((0, 0, 1, 1), xlim=(0, WIDTH_MM), ylim=(0, HEIGHT_MM))
    ax.set_axis_off()
    texts, points, mappings = [], [], []

    def text(x, y, content, role, **kwargs):
        require(';' not in content and '\uff1b' not in content, 'Semicolon in figure text')
        style = dict(va='center', ha='left', fontsize=FONTSIZE,
                     color='#1c1c1c', linespacing=1.10)
        style.update(kwargs)
        item = ax.text(x, y, content, **style)
        texts.append((role, content, item))
        return item

    def point(x, y, state, role):
        kwargs = dict(color=COLORS[state], marker=MARKERS[state], linestyle='none',
                      markersize=5.5 if state == 'PASS' else (6.1 if state == 'FAIL' else 7.2),
                      markeredgewidth=1.25 if state == 'FAIL' else 1.3)
        item, = ax.plot([x], [y], **kwargs)
        points.append((role, item))
        return item

    for panel, title, origin, groups in PANELS:
        text(origin + 1.5, 52.5, title, f'{panel}:title', fontweight='bold', fontsize=9.0)
        headers = ('PoV' if panel == 'native' else 'Checker', '741\ntests', 'M32-01', 'Controls')
        for col, header in enumerate(headers):
            text(origin + X_COLUMNS[col], 44.5, header, f'{panel}:header:{col}', ha='center')
        ax.plot([origin + 28.5, origin + 71.1], [40.8, 40.8], color='#c8c8c8', lw=0.45)
        for row_index, (group, label) in enumerate(groups):
            y = Y_ROWS[row_index]
            text(origin + 1.5, y, label, f'{panel}:row:{group}')
            for col_index, phase in enumerate(PHASES):
                row = indexed[(panel, group, phase)]
                x = origin + X_COLUMNS[col_index]
                point(x, y, row['state'], f'{panel}:{group}:{phase}')
                mappings.append({k: v for k, v in row.items() if not k.startswith('_')} |
                                {'compact_panel': panel, 'compact_row': row_index + 1,
                                 'compact_column': col_index + 1, 'x_mm': round(x, 2),
                                 'y_mm': y, 'symbol': MARKERS[row['state']],
                                 'color': COLORS[row['state']],
                                 'source_csv_lines': row['_source_csv_lines']})
        if panel == 'native':
            text(origin + X_COLUMNS[0], 16.6, '0/7', 'native:candidate_passes', ha='center',
                 color=COLORS['FAIL'], fontweight='bold', fontsize=9.0)
        else:
            text(origin + X_COLUMNS[0], 16.6, '7/7', 'historical:candidate_passes', ha='center',
                 color=COLORS['PASS'], fontweight='bold', fontsize=9.0)
    ax.annotate('', xy=(55.5, 29.9), xytext=(55.5, 34.9),
                arrowprops=dict(arrowstyle='-|>', color='#333333', lw=0.7,
                                shrinkA=0, shrinkB=0, mutation_scale=6))
    text(57.3, 32.4, 'XML only', 'xml_only_change')
    ax.plot([72.0, 72.0], [9.0, 56.0], color='#d2d2d2', lw=0.45)
    for x, state, label in ((5.0, 'PASS', 'Pass'), (25.0, 'FAIL', 'Fail'),
                            (44.0, 'NOT_RUN', 'Not run')):
        point(x, 4.6, state, f'legend:{state}')
        text(x + 3.5, 4.6, label, f'legend:{state}:label')
    text(76.0, 4.6, 'Fractions count candidates', 'candidate_count_note')
    return fig, texts, points, mappings


def layout_audit(fig, texts, points):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    boundary = fig.bbox
    issues, text_boxes = [], []
    for role, content, item in texts:
        box = item.get_window_extent(renderer)
        text_boxes.append((role, content, box))
        if not (box.x0 >= boundary.x0 and box.y0 >= boundary.y0 and
                box.x1 <= boundary.x1 and box.y1 <= boundary.y1):
            issues.append({'kind': 'text_out_of_bounds', 'role': role})
        if item.get_fontsize() < 8.0:
            issues.append({'kind': 'font_below_8pt', 'role': role})
    for i, (role_a, _, box_a) in enumerate(text_boxes):
        for role_b, _, box_b in text_boxes[i + 1:]:
            if box_a.overlaps(box_b):
                issues.append({'kind': 'text_overlap', 'a': role_a, 'b': role_b})
    for role, artist in points:
        point_box = artist.get_window_extent(renderer)
        if not (point_box.x0 >= boundary.x0 and point_box.y0 >= boundary.y0 and
                point_box.x1 <= boundary.x1 and point_box.y1 <= boundary.y1):
            issues.append({'kind': 'marker_out_of_bounds', 'role': role})
        for text_role, _, text_box in text_boxes:
            if point_box.overlaps(text_box):
                issues.append({'kind': 'marker_text_overlap', 'marker': role, 'text': text_role})
    return {'width_mm': WIDTH_MM, 'height_mm': HEIGHT_MM,
            'insert_width_mm': INSERT_WIDTH_MM,
            'height_after_insertion_mm': HEIGHT_MM * INSERT_WIDTH_MM / WIDTH_MM,
            'minimum_font_pt': min(item.get_fontsize() for _, _, item in texts),
            'minimum_font_after_insertion_pt': min(item.get_fontsize() for _, _, item in texts) *
                                               INSERT_WIDTH_MM / WIDTH_MM,
            'text_objects': len(texts), 'data_markers': len(points) - 3,
            'legend_markers': 3, 'issues': issues,
            'all_figure_text': [content for _, content, _ in texts]}


def previews(fig):
    preview = QA / 'Fig3_compact_preview.png'
    fig.savefig(preview, dpi=220, bbox_inches=None, facecolor='white')
    with Image.open(preview) as im:
        rgb = np.asarray(im.convert('RGB'), dtype=float) / 255.0
        ImageOps.grayscale(im).convert('RGB').save(QA / 'Fig3_compact_grayscale.png', dpi=(220, 220))
    # Machado full-strength protanopia/deuteranopia linear-RGB transforms.
    matrices = {
        'protanopia': [[0.152286, 1.052583, -0.204868], [0.114503, 0.786281, 0.099216],
                       [-0.003882, -0.048116, 1.051998]],
        'deuteranopia': [[0.367322, 0.860646, -0.227968], [0.280085, 0.672501, 0.047413],
                         [-0.011820, 0.042940, 0.968881]]}
    linear = np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)
    for name, matrix in matrices.items():
        transformed = np.clip(linear @ np.asarray(matrix).T, 0, 1)
        srgb = np.where(transformed <= 0.0031308, transformed * 12.92,
                        1.055 * transformed ** (1 / 2.4) - 0.055)
        Image.fromarray(np.uint8(np.clip(srgb, 0, 1) * 255 + 0.5)).save(
            QA / f'Fig3_compact_{name}.png', dpi=(220, 220))


def export(fig):
    result = {}
    for suffix in ('pdf', 'svg', 'png'):
        path = FIGS / f'Fig3.{suffix}'
        metadata = {'CreationDate': None, 'ModDate': None} if suffix == 'pdf' else (
            {'Date': None} if suffix == 'svg' else None)
        fig.savefig(path, dpi=420, bbox_inches=None, facecolor='white', metadata=metadata)
        result[suffix] = file_info(path)
    with Image.open(FIGS / 'Fig3.png') as raster:
        result['png_pixels'] = list(raster.size)
        result['png_dpi'] = list(raster.info['dpi'])
        result['png_mm'] = [raster.size[i] * 25.4 / raster.info['dpi'][i] for i in (0, 1)]
        require(min(result['png_dpi']) >= 300, 'PNG density below 300 dpi')
    svg = (FIGS / 'Fig3.svg').read_text(encoding='utf-8')
    result['svg_live_text'] = '<text' in svg
    result['svg_has_raster_image'] = '<image' in svg
    try:
        import fitz
        doc = fitz.open(FIGS / 'Fig3.pdf')
        page = doc[0]
        sizes = [span['size'] for block in page.get_text('dict')['blocks']
                 if 'lines' in block for line in block['lines'] for span in line['spans']]
        result['pdf_mm'] = [page.rect.width * 25.4 / 72, page.rect.height * 25.4 / 72]
        result['pdf_minimum_font_pt'] = min(sizes)
        result['pdf_raster_images'] = len(page.get_images())
        result['pdf_fonts'] = []
        for info in page.get_fonts(full=True):
            font = doc.extract_font(info[0])
            result['pdf_fonts'].append({'name': info[3], 'type': info[2],
                                        'embedded_font_bytes': len(font[3])})
        page.get_pixmap(matrix=fitz.Matrix(220 / 72, 220 / 72)).save(
            QA / 'Fig3_compact_final_pdf.png')
        doc.close()
        require(all(abs(a - b) < 0.02 for a, b in zip(result['pdf_mm'], [WIDTH_MM, HEIGHT_MM])),
                'Actual PDF dimensions changed')
        require(result['pdf_minimum_font_pt'] >= 8.0, 'PDF font below 8 pt')
        require(result['pdf_raster_images'] == 0, 'PDF contains raster images')
        require(all(f['embedded_font_bytes'] > 0 and f['type'] != 'Type3'
                    for f in result['pdf_fonts']), 'Unembedded or Type3 PDF font')
    except ImportError:
        result['pdf_object_check'] = 'PyMuPDF unavailable, not inspected'
    require(result['svg_live_text'] and not result['svg_has_raster_image'], 'SVG is not live vector text')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--export', action='store_true', help='Export PDF/SVG/PNG after preview review')
    args = parser.parse_args()
    cells, indexed, source = load_and_validate()
    scienceplots_used, font_file = setup_style()
    fig, texts, points, mappings = make_plot(indexed)
    audit = layout_audit(fig, texts, points)
    previews(fig)
    json_write(QA / 'Fig3_compact_layout.json', audit)
    require(not audit['issues'], f'Layout issues detected: {audit["issues"]}')
    fieldnames = list(mappings[0])
    with (DATA / 'Fig3_compact_audit.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(mappings)
    summary = {
        'purpose': 'Compare execution states while retaining all 28 R23 plot-cell mappings',
        'inputs': [file_info(DATA / name) for name in
                   ('Fig3_plot_cells.csv', 'Fig3_source_cells.csv', 'Fig3_source_manifest.csv')],
        'before': {'version_phase_records': len(source), 'plot_cells': len(cells)},
        'after': {'plotted_symbols': len(mappings), 'filtered_plot_cells': 0,
                  'native_rows': 3, 'earlier_rows': 4, 'checks_per_row': 4},
        'state_counts': dict(Counter(r['state'] for r in cells)),
        'statistical_unit': 'Recorded version-by-check states, not independent vulnerability samples',
        'grouping': 'R23 identical-state groups reused without aggregation changes',
        'native_741_includes_pov': True,
        'fractions': {'native_0_of_7': 'Candidates passing native PoV and all-test checks',
                      'earlier_7_of_7': 'Candidates passing the earlier four-input checker'},
        'build_failure': 'Row label only, its four plotted check states remain NOT_RUN',
        'uncertainty': 'No random sampling, confidence interval, or significance test',
        'all_data_inputs_confined_to_packaged_plot_data': True,
        'layout': audit,
        'environment': {'python': platform.python_version(), 'matplotlib': matplotlib.__version__,
                        'numpy': np.__version__, 'scienceplots_used': scienceplots_used,
                        'font_file': font_file, 'platform': platform.platform()},
        'visual_review': 'Manual review is recorded separately in qa/Fig3_COMPACT_QA_CN.md',
        'new_experiments': 0, 'external_model_calls': 0}
    if args.export:
        summary['exports'] = export(fig)
    json_write(DATA / 'Fig3_compact_audit.json', summary)
    plt.close(fig)
    print(json.dumps({'plot_cells': len(mappings), 'width_mm': WIDTH_MM,
                      'height_mm': HEIGHT_MM, 'layout_issues': audit['issues'],
                      'minimum_font_pt': audit['minimum_font_pt'], 'exported': args.export}))


if __name__ == '__main__':
    main()






