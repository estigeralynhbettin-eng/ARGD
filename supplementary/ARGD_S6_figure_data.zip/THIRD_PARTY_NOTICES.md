# Drawing-helper provenance

_fig4_visual_qa.py is byte-inherited from the R24 figure layer. Its earlier
provenance and source hash are retained inside the immutable R24 S6 archive
under detail_r23/tools/THIRD_PARTY_NOTICES.md. No external service is invoked
by this helper. Matplotlib, NumPy, SciencePlots, Pillow and PyMuPDF remain
separately installed dependencies governed by their own licenses.


# Retained layout helper

The bundled visual_qa.py is retained from the mp-plotting layout-checking helper. It checks missing glyphs, clipping and tick-label overlap. It does not call a model or execute a vulnerability experiment. Its source SHA-256 is `9acecca585444cb92bed40758ad7c28cb9eebb103c5682782ba262ac3ba382e5`. Original comments are retained. No blanket relicensing of third-party materials is asserted. Font files are not distributed.
