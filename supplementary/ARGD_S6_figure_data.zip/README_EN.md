> Public release copy, prepared on 8 November 2026. Machine-local workspace roots in this copy use `PUBLIC_PATH_REDACTED/`. Original source identities and numerical observations are retained. Historical byte-preservation statements below describe the retained submission source. The public-copy file hashes are listed in this archive's manifest and in the repository publication records. Consult `PUBLICATION_PROVENANCE.md` in the repository for the public-copy scope.

# ARGD current figure data and editable diagrams

This companion contains the five current manuscript figures, two editable Draw.io diagrams, the source tables and plotting scripts for three data figures, and source-identification metadata. It packages existing records and does not execute vulnerability experiments or model services.

## Diagram sources

Open diagram_sources/Fig1.drawio and Fig2.drawio with Draw.io. Their associated SVGs are also supplied. The frozen PDFs in figures are the exact manuscript originals. The XML describes native editable shapes. Export geometry or PDF bytes may vary with the Draw.io version.

## Data figure reproduction

Use a working copy, Python 3.11 or newer, the packages pinned in requirements.txt, and a separately installed Times New Roman font. Font files are not distributed. From this directory run the following commands.

    python tools/plot_fig3_compact.py --export
    python tools/plot_fig4_compact.py
    python tools/plot_fig6_compact.py

The retained script and data names use historical numbering. plot_fig6_compact.py produces the evaluator chart now numbered Figure 5. FIGURE_MAP.json records this mapping and the frozen manuscript PDF hashes. Keep regenerated outputs separately when comparing against the frozen originals. Rendering can vary with the operating system, fonts and dependency versions.

All three scripts read sibling plot_data files only. Figure 3 retains 28 grouped cells and their 76 source version-phase records. Figure 4 retains all 240 condition records. The evaluator figure retains 576 decision records and 18 aggregate cells. The code performs deterministic aggregations and plot checks. Source manifests retain historical provenance locators as metadata, without resolving them as filesystem dependencies.

The current source-screening results remain documented in S5. The retired AI-generated screening figure and older alternative figure packages are omitted from this publication copy. Original author-review archives remain internally preserved. No original observation or selected plotting input was altered while preparing this companion.

## Rights and provenance

THIRD_PARTY_NOTICES.md preserves the retained helper provenance and source hash. Third-party libraries and source artifacts retain their respective rights. No blanket relicensing of third-party materials is asserted. REPACK_PROVENANCE.json identifies the retained source layers by member and hash. MANIFEST_SHA256.csv covers the supplied files except itself.
