# Attribution for code quoted in archived model responses

The original response bodies and parsed records remain unchanged. Some historical responses quote or propose code and diffs for upstream projects. These quotations retain applicable upstream rights.

At least two explicit excerpts occur in records/evaluators/deepseek_glm/openai_evidence_ablation_decisions.jsonl. Line 180 raw_text contains a Java fragment associated with VUL4J-10 and CVE-2013-2186 in Apache Commons FileUpload. Line 183 raw_text contains a proposed TokeniserState diff associated with VUL4J-59 and CVE-2015-6748 in jsoup. Line numbers identify the archived JSONL records, without asserting that the model-produced snippet exactly reproduces an upstream commit.

Apache Commons FileUpload is distributed under the Apache License Version 2.0. Commons_FileUpload/LICENSE.txt and NOTICE.txt were retrieved from commit c61ff05b3241cb14d989b67209e57aa71540417a, which is the fixed commit recorded in the retained Commons FileUpload source-archive plan for VUL4J-11. This identifies an observed upstream license and notice for the relevant project. The exact source revision quoted by each model-generated excerpt is not independently established by this addendum.

jsoup/LICENSE is the actual MIT license file from the historical jsoup-1.8.3 tag, preserving Jonathan Hedley's 2009 to 2015 copyright and permission notice. This is a verified historical release-tag license. The archived model response does not identify an exact originating code commit, so no exact-commit attribution is inferred from the license file.

The files are included for their applicable upstream components. They do not relicense the complete response corpus, certify provider output ownership, or replace the original provenance records. Derived numerical metrics remain distinct from the quoted source content. No blanket Creative Commons or other new license is assigned to this supplementary corpus.

LICENSE_SOURCE_MANIFEST.csv records the exact upstream file URLs and checksums. The original MANIFEST_SHA256.csv and all original audit input bytes are retained. PUBLICATION_ADDENDUM_MANIFEST_SHA256.csv covers the complete augmented outer archive and distinguishes new members from originals.
