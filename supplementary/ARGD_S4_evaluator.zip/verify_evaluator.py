#!/usr/bin/env python3
"""Audit archived evaluator records using only Python's standard library.

No inference, service request, external command, or vulnerability test is run.
Historical decisions and labels remain unchanged.
"""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys

PROVIDERS = ('claude', 'deepseek', 'glm', 'qwen', 'qwen35_9b', 'qwen35_27b')
VARIANTS = ('llm_only', 'pov_only', 'pov_regression')
DECISIONS = ('approve_fix', 'block_fix', 'request_more_evidence')
FULL_CORRECT = dict(zip(PROVIDERS, (32, 32, 32, 23, 32, 31)))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_file(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def json_lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]


def csv_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def write_csv(path, rows):
    require(bool(rows), 'No output rows: ' + path.name)
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def verify_manifest(root):
    rows = csv_rows(root / 'MANIFEST_SHA256.csv')
    seen = set()
    for row in rows:
        rel = Path(row['path'])
        require(not rel.is_absolute() and '..' not in rel.parts, 'Unsafe manifest path')
        require(row['path'] not in seen, 'Duplicate manifest path: ' + row['path'])
        seen.add(row['path'])
        path = (root / rel).resolve()
        require(path.is_relative_to(root), 'Path leaves package root')
        require(path.is_file() and not path.is_symlink(), 'Missing or symbolic-link file: ' + row['path'])
        require(path.stat().st_size == int(row['bytes']), 'Byte length mismatch: ' + row['path'])
        require(sha(path) == row['sha256'], 'SHA256 mismatch: ' + row['path'])
    provenance = json_file(root / 'SOURCE_PROVENANCE.json')
    for item in provenance['byte_preserved_files']:
        require(item['package_path'] in seen, 'Original file absent from manifest')
        require(sha(root / item['package_path']) == item['archive_sha256'], 'Original bytes changed')
    return len(rows)


def strict_decision(text):
    try:
        parsed = json.loads(text.strip())
    except (ValueError, TypeError):
        return None
    if isinstance(parsed, dict) and parsed.get('decision') in DECISIONS:
        return parsed['decision']
    return None


def audit(root, output):
    manifest_count = verify_manifest(root)
    require(output != root, 'Output must be a separate directory')
    for part in ('records', 'historical_audit', 'example_output'):
        protected = (root / part).resolve()
        require(output != protected and not output.is_relative_to(protected), 'Output overlaps preserved inputs')
    truth_rows = json_file(root / 'records/challenge/runnable_validation_results.json')
    inventory = csv_rows(root / 'candidate_inventory.csv')
    truth = {row['candidate_id']: row for row in truth_rows}
    require(len(truth_rows) == len(truth) == len(inventory) == 32, 'Expected 32 unique candidates')
    require(len({row['candidate_id'] for row in inventory}) == 32, 'Duplicate inventory candidate')
    require(set(truth) == {row['candidate_id'] for row in inventory}, 'Candidate ID sets differ')
    for row in inventory:
        require(all(row[k] == truth[row['candidate_id']][k] for k in ('vul_id', 'candidate_type')), 'Inventory differs from labels')
    statuses = Counter(row['validation_status'] for row in truth_rows)
    types = Counter(row['candidate_type'] for row in truth_rows)
    require(statuses == {'PATCH_VALIDATED': 10, 'POV_FAILING': 18, 'REGRESSION_FAILING': 4}, 'Unexpected validation labels')
    require(types == {'true_patch': 10, 'noop_comment_decoy': 10, 'partial_condition_decoy': 6, 'overrestrict_condition_decoy': 6}, 'Unexpected candidate categories')
    require(len({row['vul_id'] for row in truth_rows}) == 10, 'Expected 10 vulnerability IDs')
    require(all(row['verified_should_approve'] == (row['validation_status'] == 'PATCH_VALIDATED') for row in truth_rows), 'Inconsistent validation labels')
    files = sorted((root / 'records/evaluators').glob('*/*_decisions.jsonl'))
    require(len(files) == 5, 'Expected five original decision files')
    rows = [row for path in files for row in json_lines(path)]
    require(len(rows) == 576, 'Expected 576 archived logical decisions')
    index = {(row['provider'], row['task_id'], row['evidence_variant']): row for row in rows}
    require(len(index) == len(rows), 'Duplicate provider/candidate/condition combination')
    require(set(index) == {(p, candidate, v) for p in PROVIDERS for candidate in truth for v in VARIANTS}, 'Incomplete or unknown decision cell')
    row_index = []
    for path in files:
        for line_number, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
            if line.strip():
                row = json.loads(line)
                row_index.append({'provider': row['provider'], 'candidate_id': row['task_id'], 'variant': row['evidence_variant'], 'record_file': path.relative_to(root).as_posix(), 'line': line_number})
    comparisons = []
    for row in rows:
        label = truth[row['task_id']]
        valid = label['validation_status'] == 'PATCH_VALIDATED'
        expected = 'approve_fix' if valid else 'block_fix'
        require(row['vul_id'] == label['vul_id'] and row['candidate_type'] == label['candidate_type'], 'Decision identity differs from label')
        require(row['validation_status'] == label['validation_status'], 'Decision status differs from label')
        require(row['verified_should_approve'] == valid, 'Historical approval label mismatch')
        require(row['decision'] in DECISIONS + ('invalid',), 'Unknown historical decision')
        correct = row['decision'] == expected
        require(row['verified_correct'] == correct, 'Historical correctness flag mismatch')
        require(all(row.get(k) == label.get(k) for k in ('pov_metrics', 'regression_metrics')), 'Supplied test metrics differ from validation record')
        require(bool(row.get('raw_text')), 'Missing recorded response body')
        strict = strict_decision(row['raw_text'])
        if strict is not None:
            require(strict == row['decision'], 'Strict and archived valid decisions disagree')
        comparisons.append({'provider': row['provider'], 'candidate_id': row['task_id'], 'variant': row['evidence_variant'], 'historical_decision': row['decision'], 'historical_correct': correct, 'strict_json_parseable': strict is not None, 'strict_decision': strict or 'invalid', 'strict_correct': strict == expected, 'historical_parser_repaired': bool(row.get('parsed', {}).get('_parse_repaired'))})
    metrics = []
    parser = []
    for p in PROVIDERS:
        for v in VARIANTS:
            group = [row for row in rows if row['provider'] == p and row['evidence_variant'] == v]
            comp = [row for row in comparisons if row['provider'] == p and row['variant'] == v]
            require(len(group) == 32, 'Wrong cell denominator')
            models = {row['model'] for row in group}
            require(len(models) == 1, 'Configuration model label varies within a cell')
            metric = {'provider': p, 'recorded_request_model': next(iter(models)), 'variant': v, 'n': 32,
                      'correct': sum(row['verified_correct'] for row in group),
                      'false_approve': sum(row['decision'] == 'approve_fix' and not row['verified_should_approve'] for row in group),
                      'false_block': sum(row['decision'] == 'block_fix' and row['verified_should_approve'] for row in group),
                      'defer_valid': sum(row['decision'] == 'request_more_evidence' and row['verified_should_approve'] for row in group),
                      'defer_invalid': sum(row['decision'] == 'request_more_evidence' and not row['verified_should_approve'] for row in group),
                      'invalid_output': sum(row['decision'] == 'invalid' for row in group),
                      'false_approval_denominator': 22, 'valid_retention_denominator': 10}
            metrics.append(metric)
            parser.append({'provider': p, 'variant': v, 'n': 32,
                           'strict_parseable': sum(row['strict_json_parseable'] for row in comp),
                           'archived_correct': sum(row['historical_correct'] for row in comp),
                           'strict_correct': sum(row['strict_correct'] for row in comp),
                           'parser_repaired': sum(row['historical_parser_repaired'] for row in comp)})
    for filename, current, columns in [
        ('evaluator_metrics_recomputed.csv', metrics, ('n', 'correct', 'false_approve', 'false_block', 'defer_valid', 'defer_invalid', 'invalid_output')),
        ('parser_sensitivity_summary.csv', parser, ('n', 'strict_parseable', 'archived_correct', 'strict_correct', 'parser_repaired'))]:
        prior = csv_rows(root / 'historical_audit' / filename)
        mapping = {(row['provider'], row['variant']): row for row in prior}
        require(len(prior) == len(mapping) == len(current) == 18, 'Historical summary cells differ')
        for row in current:
            saved = mapping[(row['provider'], row['variant'])]
            require(all(row[k] == int(saved[k]) for k in columns), 'Recomputed metrics differ from historical audit: ' + filename)
    full = [row for row in metrics if row['variant'] == 'pov_regression']
    require({row['provider']: row['correct'] for row in full} == FULL_CORRECT, 'Full-evidence expected observations changed')
    q9 = next(row for row in parser if row['provider'] == 'qwen35_9b' and row['variant'] == 'pov_regression')
    require((q9['archived_correct'], q9['strict_correct'], q9['parser_repaired']) == (32, 25, 7), 'Qwen3.5 parser sensitivity changed')
    example_id = 'VUL4J-10_overrestrict_condition_decoy'
    example = index[('qwen', example_id, 'pov_regression')]
    require(example['decision'] == 'approve_fix' and example['validation_status'] == 'REGRESSION_FAILING', 'Expected false acceptance missing')
    require(example['pov_metrics']['number_running'] == example['pov_metrics']['number_passing'] == 1, 'Example PoV differs')
    require(tuple(example['regression_metrics'][k] for k in ('number_running', 'number_passing', 'number_failing', 'number_error', 'number_skipping')) == (70, 67, 3, 0, 0), 'Example regression metrics differ')
    locator = {(row['provider'], row['candidate_id'], row['variant']): row for row in row_index}
    examples = []
    for p in ('qwen', 'claude'):
        record = index[(p, example_id, 'pov_regression')]
        examples.append({'locator': locator[(p, example_id, 'pov_regression')], 'record_unchanged': record})
    require(examples[1]['record_unchanged']['decision'] == 'block_fix', 'Same-input contrast differs')
    summary = {'candidate_units': 32, 'vulnerability_units': 10, 'candidate_type_counts': dict(sorted(types.items())),
               'validation_status_counts': dict(sorted(statuses.items())), 'evaluator_configurations': 6,
               'evidence_conditions': list(VARIANTS), 'logical_decisions': 576, 'response_body_records': 576,
               'original_decision_files': 5, 'historical_invalid_decisions': sum(row['decision'] == 'invalid' for row in rows),
               'full_evidence': full, 'qwen35_9b_full_evidence_parser_sensitivity': q9,
               'transport_attempt_count': 'NOT_RETAINED', 'full_wire_request_or_response': 'NOT_RETAINED',
               'new_model_calls': 0, 'new_vulnerability_tests': 0}
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / 'summary.json', summary)
    write_csv(output / 'decision_metrics.csv', metrics)
    write_csv(output / 'parser_sensitivity.csv', parser)
    write_csv(output / 'record_index.csv', row_index)
    write_csv(output / 'parser_comparison_records.csv', comparisons)
    write_json(output / 'example_false_acceptance.json', examples)
    receipt = {'status': 'PASS_OFFLINE_ARCHIVED_RECORD_AUDIT', 'finished_utc': datetime.now(timezone.utc).isoformat(),
               'python_version': platform.python_version(), 'platform': platform.system(),
               'manifest_entries_verified': manifest_count, 'manifest_sha256': sha(root / 'MANIFEST_SHA256.csv'),
               'candidate_units': 32, 'vulnerability_units': 10, 'logical_decisions': 576,
               'historical_summary_cells_matched': 18, 'strict_parser_cells_matched': 18,
               'original_decisions_or_labels_modified': False, 'new_model_calls': 0, 'new_vulnerability_tests': 0,
               'output_sha256': {p.name: sha(p) for p in sorted(output.iterdir()) if p.is_file() and p.name != 'execution_receipt.json'}}
    write_json(output / 'execution_receipt.json', receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path.cwd() / 'evaluator_audit_output', help='Output directory, separate from preserved package inputs')
    args = parser.parse_args()
    try:
        receipt = audit(Path(__file__).resolve().parent, args.output.resolve())
    except (ValueError, KeyError, OSError, TypeError, json.JSONDecodeError) as error:
        print('AUDIT FAILED: ' + str(error), file=sys.stderr)
        return 1
    print(json.dumps({k: receipt[k] for k in ('status', 'candidate_units', 'vulnerability_units', 'logical_decisions', 'new_model_calls', 'new_vulnerability_tests')}, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
