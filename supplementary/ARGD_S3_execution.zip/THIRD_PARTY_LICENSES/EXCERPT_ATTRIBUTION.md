# Attribution for retained source excerpts

The two Apache Struts method excerpts in legacy/ARGD_S3_execution_legacy_r20.zip under audit/TARGET_METHOD_CANDIDATES_4_INPUTS.java.txt and audit/TARGET_METHOD_T0_6_INPUTS.java.txt retain their original archived bytes. They are extracts of DefaultExcludedPatternsCheckerTest.testParamWithClassInName for the four-input and six-input fixture identities described in the original evidence.

Apache Struts is distributed by the Apache Software Foundation under the Apache License Version 2.0. The accompanying Apache_Struts/LICENSE.txt and Apache_Struts/NOTICE.txt were retrieved from the confirmed developer-fix commit d832747d647df343ed07a58b1b5e540a05a4d51b. Both files match the SHA256 identities already retained in the native source-tree manifest. The two original excerpts are isolated method extracts and omit file-level preambles. The accompanying license and project notice supply the upstream attribution without modifying the recorded excerpt bytes.

The ARGD matrix test and adapter remain separately identified as author-created test material in the original RIGHTS_AND_SOURCES.md. No blanket new license is assigned to the research records or to unrelated software. This addendum supplements the original rights statement. Original reports, source excerpts, JUnit XMLs and the complete nested legacy ZIP are byte-preserved.

LICENSE_SOURCE_MANIFEST.csv records the exact upstream file URLs and checksums. PUBLICATION_ADDENDUM_MANIFEST_SHA256.csv distinguishes original preserved members from new license and attribution members.
