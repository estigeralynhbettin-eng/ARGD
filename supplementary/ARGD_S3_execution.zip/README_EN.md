> Public release copy, prepared on 8 November 2026. Machine-local workspace roots in this copy use `PUBLIC_PATH_REDACTED/`. Original source identities and numerical observations are retained. Historical byte-preservation statements below describe the retained submission source. The public-copy file hashes are listed in this archive's manifest and in the repository publication records. Consult `PUBLICATION_PROVENANCE.md` in the repository for the public-copy scope.

# R21 execution evidence addendum

This documentation archive preserves the exact R20 execution companion under legacy/. Read it together with this addendum. The historical custom adapter used four-input candidate checkers; controls used six inputs. Its passes are not native Vul4J acceptance.

All seven revalidated candidates compiled but failed both native PoV and all-test phases (0/7 pass). These phases include the same failing legitimate-name assertion. The native candidate matrix was not run.

The native packaged human repair passes 3 PoV and 741 all-tests but fails M32-01. The complete-XML control passes 3, 741 and all four matrix checks. Comparing both 4,724-entry input manifests identifies only the production XML change. Original JUnit and result files are unchanged. A report's historical pending-review heading is superseded by the separately retained independent review, not silently rewritten.

New addendum content comprises result data, reports, identities and source indexes. New candidate code, patches, PoV inputs and test source are not redistributed here. Original executable materials stay at the governed sources identified by the manuscript evidence index. The legacy archive remains unchanged and contains its original tests. No code was executed to prepare R21. This is author-review preparation, not a public release or submission-frozen package.

ORIGINAL_JUNIT_INDEX.csv maps every numbered original XML member to its version, phase, source identity, hash and test counts.
