# ARGD 原生Vul4J核验结果

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run
- Origin Date: 2026-10-25
- Verification Status: EXECUTED; INDEPENDENT_REVIEW_RECORDED_SEPARATELY
- Version Label: native_vul4j32_validation_v1

## 直接结论

旧Recovery3与本次原生验证不是同一个实验。按作者授权，把同一七份候选Java原字节放回官方VUL4J-32分支和原生验证流程后，七份均可编译；**原生验证通过0/7，断言失败7/7**。这是一家族的七个相关候选，不是七个独立漏洞。

七份均在原生目标测试的合法参数名检查中失败。具体错误消息见逐候选表和原XML；本轮没有建立“这些候选通过原生Vul4J，由矩阵才新增拒绝”的结果。

## 实际逐项结果

| 对象 | 编译 | 原生PoV | 原生全部回归 | 四项补测 |
|---|---|---|---|---|
| 漏洞原版 | 通过 | 3项中1项失败 | 741项中1项失败 | M32-01失败，其余通过 |
| native human_patch | 通过 | 3项通过 | 741项通过 | M32-01失败，其余通过 |
| 220 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |
| 221 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |
| 222 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |
| 223 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |
| 224 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |
| 226 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |
| 227 | 通过 | 3项中1项失败 | 741项中1项失败 | 未执行 |

原生全部回归包含目标PoV；两个阶段中的同一失败不能算两个独立发现。候选矩阵未执行，不能把“未执行”写成通过或失败。权限准备错误保留在早期控制记录中，未算候选失败。

## 为什么这次与旧记录不同

旧实验通过我们写的Maven适配器运行parent树中的检查。原生实验使用官方分支、Java7/Maven3.3.9及native checkout/compile/test -b povs/test -b all。

关键差异是输入：旧候选的同名目标方法检查四种参数名；官方分支检查六种。原生目标测试类共有三个方法，其中`testParamWithClassInName`会检查六个参数名。七个候选都错误排除了合法名字`class.super@demo.com`，因此原生检查直接失败。旧记录和本次回归都显示741项，也不能据此认为输入相同。

源2026研究的INEFFECTIVE历史标签仍保留；其底层失败路径缺证，与本次原生实测失败原因分开。本次观察不回写当时档案或盲态。

## 补测校准遇到的真实边界

预先约定用漏洞版和native human_patch校准四项补测，要求人修复控制通过。实际两个控制均仅M32-01失败，其余三项通过，因此原成对方案停止，未放行七候选补测。

静态逐字节核对进一步确认，native human_patch与完整Apache d832747修复的checker Java、ParametersInterceptor和xwork-param-test.xml相同，但struts-default.xml不同。原生框架只恢复生产Java，保留官方基准分支的XML；其中defaultStack仍把排除规则覆写为`^action:.*,^method:.*`。完整开发者修复则没有该覆写。冻结补测读取该版本自己的XML，观察到`#request['marker']`未被名称过滤规则排除。

因此，native human_patch不能直接当作包含全部Java/XML修改的Apache完整修复。M32-01只检查isExcluded子判定，没有验证完整isAccepted链路、执行OGNL或完整HTTP攻击。这些证据也不足以单独认定补测oracle错误。

为完成作者已授权的原生问题，本轮单独登记native_only_scope，只复用已实测且独立核对的原生compile/povs/all控制。其receipt明确`matrix_calibration_passed=false`，原配对方案保持停止。没有为了通过修改候选、XML、PoV或矩阵断言。

## 对论文结论的影响

本轮不能支持矩阵相对原生Vul4J的额外检出收益。可保留的是四项检查的组织与来源追溯、旧协议下的配置观察，以及本轮原生基准上下文差异。矩阵相对普通同预算补测是否有效，仍未验证。

R20稿件、本轮之前的实验、第三方原标签和项目根结果账本均未改写。若论文要叙述“原生基准认可的补丁仍有遗漏”，需要另有符合该条件的证据，不能继续用这七份支持该对比。

## 复核入口

- [逐候选CSV](PUBLIC_PATH_REDACTED/ARGD/02_experiments/runs/ARGD_NATIVE_VUL4J32_VALIDATION_20261025_V1/CANDIDATE_NATIVE_SUMMARY.csv)
- [原生七候选完整结果](PUBLIC_PATH_REDACTED/ARGD/02_experiments/runs/ARGD_NATIVE_VUL4J32_VALIDATION_20261025_V1/native_only_scope/CANDIDATE_RESULTS.json)
- [原始XML、命令和输入快照](PUBLIC_PATH_REDACTED/ARGD/02_experiments/runs/ARGD_NATIVE_VUL4J32_VALIDATION_20261025_V1/outputs)
- [实际源码差异](PUBLIC_PATH_REDACTED/ARGD/02_experiments/runs/ARGD_NATIVE_VUL4J32_VALIDATION_20261025_V1/evidence/context_diagnosis/FULL_FIX_VS_OFFICIAL_BRANCH.diff)
- [旧协议与原生协议对照](PUBLIC_PATH_REDACTED/ARGD/05_reviews/argd_native_validation_execution_20261025/OLD_VS_NATIVE_PROTOCOL_COMPARISON_CN.md)
- 独立复核报告与最终回执见本run的`independent_review/`和`DELIVERY_RECEIPT.json`；工程审计通过不等于投稿冻结。

## 复现说明

入口为native_only_scope/RUN_REQUEST.json和冻结execute_native_v3.py。原生CLI、实际命令、环境、输入身份和阶段退出码均按对象归档。新run需要独立输出和明确授权，不直接重新提交相同run_id。官方分支固定为c0c3530b3e0c5ad613e551fb68d01e7a75b2964e，框架内容固定为上游376411da11fa705019f731404de1d0679fe73537对应47文件，JDK/Maven工具链校验值见evidence/PREPARE_RUNTIME.json。无新模型/API调用、补丁生成、发布或投稿。
