# VUL4J-32 完整修复配置校准结果

日期：2026-10-25  
运行包：`ARGD_NATIVE_VUL4J32_FULL_FIX_MATRIX_CALIBRATION_20261025_V3`  
状态：正式运行完成；结果与原始 Surefire 报告核对通过；RUN_STATUS 保留 `COMPLETED_PENDING_INDEPENDENT_REVIEW`。

## 直接结果

V3 在同一原生 VUL4J-32 工程中，只把相对 native `human_patch` 的 `core/src/main/resources/struts-default.xml` 替换为 Apache 完整修复提交 `d832747d647df343ed07a58b1b5e540a05a4d51b` 的版本。源码清单有 4,724 项，唯一变化路径就是该 XML；执行期间项目上下文没有其他变化。

完整修复控制编译通过。原生 PoV 的 3 项全部通过；741 项上游回归全部通过；四项冻结矩阵检查全部通过，没有失败、错误或跳过。M32-01 对应 `testM32DefaultStackPreservesRequestContextExclusion`，本次通过。

| 阶段 | 实际执行 | 通过 | 失败 / 错误 / 跳过 |
|---|---:|---:|---:|
| 编译 | 1 次 | 1 | 0 |
| 原生 PoV | 3 项 | 3 | 0 |
| VUL4J 全部回归 | 741 项 | 741 | 0 |
| 矩阵行为检查 | 4 项 | 4 | 0 |

对应原始 Surefire XML 分别位于 `outputs/full_fix_control/02_povs/`、`03_all/` 和 `04_matrix_fullfix/`；完整机器结果见 `FULL_FIX_CALIBRATION_RESULT.json`。

## 与 native human_patch 对照后能说明什么

此前原生控制记录显示，native `human_patch` 的 741 项回归也全部通过，但 M32-01 失败；该版本并非 Apache 的完整修复，因为它恢复了 Java 修复，却保留了未恢复排除规则的 `struts-default.xml`。现在换成完整 Apache XML 后，741 项仍全部通过，M32-01 则通过。

因此，在这个 VUL4J-32 配置对照中，741 项回归没有区分“排除规则未由生产默认配置保留”和“完整修复配置”这两种状态；M32-01 能区分。这个结果支持 M32-01 对该配置要求的正向校准，也说明目录化要求可以引出回归套件没有覆盖的具体检查点。它不是对 VUL4J 全套方法的评价，也不等于证明矩阵普遍优于普通补测。

## 解释边界

这是同一漏洞家族内的一个配置控制，不是新的独立漏洞样本。M32-01 检查 `defaultStack` 配置下的排除规则子行为；它没有执行 OGNL，也没有复现完整 HTTP 攻击。七个公开候选没有在本 scope 中运行，结果不改变其原生 PoV / 回归结果，也不改变原数据档案中的 `INEFFECTIVE` 标签。

本结果不能单独支持跨漏洞泛化、总体检出率、相对同信息同预算普通 LLM 补测的优势，或“原始 VUL4J 已接受这些候选、但矩阵才发现漏洞”的说法。741 是执行的测试方法；2,847 是不同来源的目录记录，两者不是同一统计单位。目录到 M32 的历史选择轨迹也没有因此被补造。

## 执行与核验记录

- T0：`PASS`，0 项科学测试、0 次模型/付费 API 调用、未联网；runner 状态 `SUCCEEDED`、退出码 0。
- 正式门禁：`ready_for_formal_run=true`，无阻断项；仅记录 `GIT_COMMIT_UNAVAILABLE` 警告。
- 正式 runner：`SUCCEEDED`、退出码 0、执行 1 次；候选运行 0、模型调用 0、付费 API 调用 0、网络 0。
- 运行请求哈希：`bc4a764d80ad302c72ef5c9ec8de2625f66e7e5cc962f6d6073f39f612e62e3f`；runner fingerprint：`22c7d87022dc7c6960f8d2c59a73701cdbd0f614b49a1f60240023190defee79`。
- 完整结果 SHA-256：`b99dcc978d3b718363989a3231b77c1003c98eb5f8f02005c2f0bfe4fd5e4f87`；runner 摘要输出 SHA-256：`b6aa989d35f6712b37eb1cde9b5a471e0cfd91007aa7735049269d8e604b35eb`。
- 完整修复 XML SHA-256：`b49e93fade035cdd3562fa20e3a0c0a65cf1fdb8a127cd4952134c1ad717c3cd`；矩阵测试源码 SHA-256：`a894f3774e37d4113bfa3f47d4ab984a80a229fe03ca0f34a8be0f5fa52fbfee`。
- T0 回执 SHA-256：`8c86d158acaae18ffc1c41b571d2429066cebed8fa78306b914ada1a0923a396`；正式门禁放行文件 SHA-256：`b200a709703d0e075dda7ced768af3ec0a970611a86a074d97728618336ba045`。
- 原生对照依据：`../ARGD_NATIVE_VUL4J32_VALIDATION_20261025_V1/NATIVE_VALIDATION_REPORT_CN.md`。七候选在该原生流程下 0/7 通过，且本次没有重跑它们。

运行前，第一版正式请求中的一个暂存路径拼写问题在 runner 验证前被发现并保留；修正后的 V2 请求通过 29 项输入哈希校验后才启动。T0 指针写入过程中的无效 JSON 也已保留在 `evidence/`，最终指针从备份恢复后验证通过；门禁只读取最终有效回执。上述准备错误均未启动科学测试，也未改变实验输入或结果。

## 下一步

先为下一独立漏洞家族核验真实项目树、PoV 来源和完整修复身份，再新建冻结 scope 与 T0；VUL4J-2 旧 V1 的错误 PoV 文件不能复用。之后还需要以相同项目资料、修复可见性和调用/时间预算，比较普通 LLM 补测与矩阵指导补测。两项工作都不能从本次单案校准结果中推定完成。