# ARGD complete source-and-scenario catalog: metadata edition

This companion preserves the **complete 2,847-record catalog**, six platform categories, 38 author-created checking questions, 16 scenarios and 146 scenario/check mappings. It also retains all 2,855 provenance metadata entries (the 2,847 catalog records plus eight supplementary source entries) and the 38-entry source registry. Counts describe an author-created planning asset, not tested patches or measured repair coverage.

The original internal workbook retains source excerpts. This submission edition removes third-party normative wording, rule/test/safeguard titles, and source summaries. Reviewers use each record's ID, version, source URL and locator to consult the original source. The edition retains all record IDs and mappings; no record or mapping has been silently deleted.

## Files

- CATALOG_METADATA.csv: 2,847 catalog IDs, source labels, versions, native IDs, ARGD platform/mechanism routing, official source URLs, locators and version pins.
- SOURCE_PROVENANCE_METADATA.csv: 2,855 ID-to-source/version/locator/link records, including eight supplementary entries.
- ARGD_CHECKS.csv: 38 researcher-created checking questions, operational procedures and expected evidence; the original source_summary column is omitted.
- ARGD_SCENARIOS.csv: 16 researcher-created scenario classes and source references.
- SCENARIO_CHECK_MAPPING.csv: all 146 scenario/check ID pairs with linked source metadata.
- SOURCE_REGISTRY.csv: all 38 framework/reference source records; zero catalog rows for a framework remain zero and do not imply implemented coverage.
- PLATFORM_ROUTING.csv: the six author-defined routing categories. The raw catalog retains its 13 historical platform/language labels (including combined labels) without forcing them into six mutually exclusive values.
- RIGHTS_AND_SOURCES.md: observed source licences and the text-omission policy.
- MANIFEST_SHA256.csv: file hashes, excluding the manifest itself.

All CSV files are UTF-8 and comma-separated, with a header row. Author-created questions and explanatory labels retain the original Chinese wording, while identifiers/URLs remain unchanged. This is a metadata export from the archived catalog; it is not a newly executed experiment or a revised source standard.

Suggested caption: "Complete ARGD source-and-scenario catalog (metadata edition): 2,847 source records, 38 checking questions, 16 scenarios and 146 mappings, with original identifiers, version pins and source locators. Third-party normative text is accessed through the original source links."
